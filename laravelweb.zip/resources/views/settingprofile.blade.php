<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
  <link rel="shortcut icon" href="img/iconsinsa4.png">
  <link rel="stylesheet" href="{{ asset('css/setting.css') }}">
  <title>Document</title>
</head>
<body>
  
@include ('layouts.app')

<a href="{{ url('/setting') }}"> <button class="btn btn-success" id="homeback2"> Setting Menu  </button> </a>
    
<div class="form-grouptotal2">  



<form action="{{ route('users.update-profile') }}"  method="POST" enctype="multipart/form-data">

@csrf
@method('PUT')



<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="{{ $usuarios->id }}">
</div>


<div class="form-group" id="form-name1"> 
<label for="name">Name</label>
<input type="text"  name="name" id="name" value="{{ $usuarios->name }}">
</div>

<!-- <div class="form-group"> 
<label for="name">Password</label>
<input type="password"  name="password" id="name" value="">
</div> -->



                        
 <input type="file" class="form-control" name="img" value="" placeholder="Imagen"  id="imgform">
                        
           
 <img src="{{asset('users/'.Auth::user()->img)}}" name="img" alt="">
      


<button type="submit" class="btn btn-success">Update Profile</button>




</form>  




@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  {{ $message }}     </span>

</div>

@endif



</div>


















</body>
</html>

            