

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="{{ asset('css/programming.css') }}">
 <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="stylesheet" href="{{ asset('css/singlepost.css') }}">
   
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  @include('layouts.topsidebar2')


     


            
<div class="home_content">

<div class="text">











@foreach($productos  as  $producto)




@if(Auth::id() == $producto->userpost_id )

<h1>You can Edit</h1>


@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  {{ $message }}     </span>

</div>

@endif


@if($message = Session::get('alertd'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  {{ $message }}     </span>

</div>

@endif


<!-- veer esto del form deee eeditar -->

<form action="{{ route('postadm.edit') }}" method="post"  enctype="multipart/form-data">
@method('PUT')
@csrf

<div class="modal-body">
 
 @if($message = Session::get('ErrorInsert')) 
<!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
@foreach($errors->all() as $error)
        <!-- traigo los errores -->
                  
<li> {{ $error }} </li>   


@endforeach

</ul>

</div>

@endif











                

<input type="hidden" name="id" id="idEdit" value="{{ $producto->id }}">
                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="{{ $producto->nombre }}" id="nombreEdit" > 


                    </div>


                    

                    <div class="form-group">
                        
<input type="text" class="form-control" name="codigo" placeholder="Codigo"  value="{{ $producto->codigo  }}" id="codigoEdit" >


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="slug" > 


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="author" value="{{ $producto->author }}" id="authorEdit" > 


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="userpost_id" value="{{ Auth::user()->id }}" id="userpostidEdit" > 


                    </div>

                    
                    <div class="form-group">

<input type="hidden" class="form-control" name="admin" value="{{ $producto->admin }}" id="adminEdit" > 


                    </div>



                    <div class="form-group">
                        
                        <textarea type="text" class="form-control" name="description" placeholder="description" value="{{ $producto->description }}" id="descriptionEdit">{{ $producto->description }}</textarea>
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                                            <input type="file" class="form-control" name="img" placeholder="Imagen" id="imgEdit" value="">  
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>






<form action="{{ route('post-delete3') }}" method="post"  class="deletcomid {{$producto->id }}">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

@csrf


<button class="btn btn-danger btnEliminar" id="btnelimi" data-id="{{$producto->id}}" data-toggle="modal" data-target="#ModalEliminar"> Click Here To Delete the Post <i class="fa fa-trash" >   </i>  </button>



<input type="hidden" name="id" value="{{ $producto->id }}">
<input type="hidden" name="_method" value="delete">

</form>


</div>

@if($message = Session::get('ErrorInsert'))

@endif








@else 

<h2> You Cannot Edit or Delete this Comment</h2>


@endif

@endforeach






</div>




</div>












@include('layouts.cookies')


</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});


$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('nombre')); // el name le puse al atributo / data-name
$("#codigoEdit").val($(this).data('codigo'));
$("#authorEdit").val($(this).data('author'));
$("#adminEdit").val($(this).data('admin'));
$("#userpostidEdit").val($(this).data('userpost_id'));

$("#slugEdit").val($(this).data('slug'));
$("#descriptionEdit").val($(this).data('description'));
$("#imgEdit").val($(this).data('img'));


});





// function  editcomment(){

// document.getElementsByClassName('editcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('deletcom').style.display = 'none';
// }

// function  deletecomment(){

// document.getElementsByClassName('deletcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('editcom').style.display = 'none';
// }


</script>


















       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    

        
  </html>
  


    






















