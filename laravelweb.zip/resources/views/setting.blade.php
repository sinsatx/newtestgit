<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
  <link rel="shortcut icon" href="img/iconsinsa4.png">
  <link rel="stylesheet" href="{{ asset('css/setting.css') }}">
  <title>Setting</title>
</head>
<body>
  
@include ('layouts.app')
    

<div class="form-grouptotal">   

<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="{{ $usuarios->id }}">
</div>


<div class="form-group" > 
  

 <a  href="settingprofile"> 
   <label for="name" id="profileset">Profile Settings </label>
  </a>

</div>


<div class="form-group"> 
<label for="name">Email: </label>
{{ $usuarios->email }}
</div>

<div class="form-group"> 
<label for="name">Name: </label>
{{ $usuarios->name }}
</div>

<!-- <div class="form-group"> 
<label for="name">Password</label>
<input type="password"  name="password" id="name" value="">
</div> -->


<div class="form-group">        
         Image Profile:   
 <img src="{{asset('users/'.Auth::user()->img)}}" name="img" alt="">

 </div>   

 


 <div class="form-group"> 
            <a href="settingpassword"> <label for="name"    id="profileset">Password Settings </label>    </a>

</div>



<div class="form-group"> 
  

 <a href="settingdelete"> 
   <label for="name"  id="profileset">Delete Account </label>
  </a>

</div>







@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  {{ $message }}     </span>

</div>

@endif


</div>


<!-- <a href="{{ url('/') }}"> <button class="btn btn-success" id="homeback"> Home  </button> </a> -->













</body>


</html>

            