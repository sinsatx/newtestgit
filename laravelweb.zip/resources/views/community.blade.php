

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="{{ asset('css/programming.css') }}">
 <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}"> 
    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    
    <link rel="stylesheet" href="{{ asset('css/jquery-ui.css') }}">

    <link rel="shortcut icon" href="img/iconsinsa4.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  @include('layouts.topsidebar2')


     
  

            
<div class="home_content">

<div class="text">



@forelse($productos as $producto)
@empty
<p class="text-center">

No Products found: <strong> {{ request()->query('search')}} </strong>

</p>
@endforelse


<a href="community/posts" class="comcreate"> 
<button class="btn btn-danger btncreat">  Create Post <i class="fa fa-pencil" > </i>   </button></a> 


<div class="postcomplet"> 

@foreach ($productos as $producto)




<div class="post">

<!-- <h2 class="textdat"> Programming - Articulos - DateBase Tabla (Datos de la Tabla) </h2>
     -->



     <img class="postImg" src="img/productos/{{$producto->img}}  "/>  

     <div class="postInfo">
<div class="postCats">
<span class="postCat">Community</span>
<span class="postCat">Posts</span>

</div>

<a href="{{route('posts.show',$producto) }} "> <span class="postTitle">  {{ $producto->nombre }} </span> </a>
<hr />

<span class="postDate"> {{ $producto->stock }} </span>
</div>


<p class="postDesc"> {{ $producto->description }} </p>

</div>



<!-- <table> 

<div class="elementocompleto"> 

<li class="elementsproducts list-group-item">Nombre: {{ $producto->nombre }} </li>

<li class="elementsproducts list-group-item">Numero:  </li>

<li class="elementsproducts list-group-item">Codigo: {{ $producto->codigo }} </li>

<li class="elementsproducts list-group-item">Descripcion: {{ $producto->description }} </li>

<li class="elementsproducts list-group-item"> <</li>




</div>


</table> -->

@endforeach






</div>







@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  {{ $message }}     </span>

</div>

@endif







</div>


</div>






@include('layouts.cookies')


</body>
        
       
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
       
        
        
        <script src="js/cookies.js">  </script>

        <script src="../js/jquery-3.6.0.min.js">  </script>
    
        <script src="../js/jquery-ui.js">  </script>
        
      




           
        <script>
        
        
      
        $('#search').autocomplete({
        
        source: function(request, response){
$.ajax({

url: "{{route('search.product')}}",
dataType: 'json',
data: {
term: request.term

},

success: function(data){

response(data)

} 


});


        }
        
        });
        
        
        
        
        
        
        
        
        
        </script>


    
















  </body>
  </html>
  


    

  








