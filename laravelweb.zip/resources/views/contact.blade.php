

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>

    <link rel="shortcut icon" href="img/iconsinsa4.png">
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>


<link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">

    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/contact.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
  <body>


  @include('layouts.topsidebar2')



  


     


            
<div class="home_content">

<div class="text">



<!-- <div class="fondoef">   -->

<!-- <div class="wrapper">
<div class="static-txt">I´ am a</div>
<ul class="dynamic-txts">
<li> <span> Youtuber </span> </li>
<li> <span> Editor </span> </li>
<li> <span> Freelancer </span> </li>
<li> <span> Full Stack Developer </span> </li>

</ul>

</div>

</div> -->

<div class="container cont1" id="contact1">
	<div class="row">
		<div class="col-md-8 mx-auto">
			<div class="contact-form send2">
				<h1 class="send1" id="send2">Send me a Message</h1>
                @if(session()->has('message'))
                    <div class="alert alert-success" id="message1">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <form action="{{ route('send.email') }}" method="post">
                @csrf


					<div class="row">
						
							<div class="form-group">
								<label for="inputName">Email</label>
								<input type="text" name="name" class="form-control" placeholder="Email">
                                
							</div>
						
							<div class="form-group" >
								<!-- <label for="inputEmail">Email</label> -->
								<input type="hidden" name="email"  class="form-control" value="sinsatoxp1@gmail.com" placeholder="Email">
                                
							</div>
						
					</div>            
					<div class="form-group">
						<label for="inputSubject">Subject</label>
                        <input type="text" name="subject" class="form-control" placeholder="Subject">
                      
					</div>
					<div class="form-group">
						<label for="inputMessage">Message</label>
                        <textarea name="content" rows="5" class="form-control" placeholder="Message"></textarea>
                      
					</div>
					<div class="text-center">
						<button type="submit" class="btn btn-primary" id="botonemail1"> <i class="fa fa-paper-plane"></i> Send</button>
					</div>            
				</form>
			</div>
      
		</div>

   

	</div>
  

</div>



@error('name')
                <div class="row2"> 
                                <span class="text-danger2"> {{ $message }} </span> <br> 
                                @enderror

                                @error('email')
                                <span class="text-danger2"> {{ $message }} </span> <br> 
                                @enderror

                                @error('subject')
                        <span class="text-danger2"> {{ $message }} </span> <br> 
                        @enderror


                        @error('content')
                        <span class="text-danger2"> {{ $message }} </span> <br> 
                        @enderror
                        </div>



<div class="contx"> 

<h3 class=formul1> || </p> <br>
  


<h3 class=formul3> You can Hire me <br> (Podes contratarme en) :</p>


<a href="https://www.fiverr.com/sinsatox">    <img src="img/fiv1.png" id="gmail1" alt="gmail" width="400px" alt=""/> </a>



</div>



</div>



</div>

         
@include('layouts.cookies')

</body>
        
        
        
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
      
        
        
        
        
      

    
        <script src="js/cookies.js">  </script>
    










</html>




  </body>
  </html>
  


    

  



