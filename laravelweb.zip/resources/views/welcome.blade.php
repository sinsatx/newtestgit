


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>
    <link rel="shortcut icon" href="img/iconsinsa4.png">
  


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>


    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="shortcut icon" href="img/iconsinsa4.png">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

@include('layouts.topsidebar2')



  

    

   


          
<div class="home_content">

<div class="text">
  


<div id="header" class="header1"> 

<div class="efprim"> 

<h1 class="h1efect">


<span>S</span>
<span>i</span>
<span>n</span>
<span>s</span>
<span>a</span>
<span>t</span>
<span>o</span>
<span>X</span>
<span>P</span>



</h1>

</div>


<div class="escribef">  



<div class="fondoef"> 
    


<div class="wrapper">
<div class="static-txt">I´ am a</div>
<ul class="dynamic-txts">
<li> <span> Youtuber </span> </li>
<li> <span> Editor </span> </li>
<li> <span> Freelancer </span> </li>
<li> <span> Full Stack Developer </span> </li>




</ul>

</div>



</div>

</div>



<p class="text1">Making website is one the things you can do in this world. You just need to learn
HTML, CSS, Javascript to do it
</p> 

<a href="/about" class="hero-btn" id="btnvisit"> Visit here to know more </a>
 


 </div>




<div class="Programming"> </div>

<section class="course">

<h1> Work </h1>






<p>  This is what I work on </p>

<a href="/programming" class="hero-btn" id="btnvisit2"> Visit here to see what I know to do </a>



<div class="row2">
<div class="course-col" id="phpzone1">

<h3> Programming </h3>
<p id="texphp"> I work as a web programmer, using mainly Laravel (a PHP framework) that provides security when using data, Javascript (ReactJs), CSS and I use MySQL as a database. </p>


</div>


<div class="course-col" id="phpzone1">
<h3> Video Editing </h3>
<p> As a video editor, the experience is mainly what you can see on Youtube </p>


</div>

<div class="course-col" >
<h3> Logo / Image Editing </h3>
<p> For this I use Adobe Photoshop, I have a lot of experience using it, I know how to edit images and create logos (not drawing).   </p>


</div>


</div>




<div class="course-admin" >
<h3> Crud / Rest Api - Laravel </h3>
<p> It is an application that is made with a database, in which you can choose what you want it to have, you can delete, edit, and create what you want it to have in it. And this you can show it so that it can be seen in detail in another page. </p>

<img src="img/comentapi2.jpg">
<br> <br>

<h3> Logo </h3>
<p> I mainly use Photoshop, I can create it based on figures and text (like the one you see in the image). </p>

<img src="img/sinsatoxlogsolg2.png">


<h3> Image Edit </h3>

<p>For image editing I use photoshop, I can change objects, add things, colors, add text, among other things. An example you can see it in the image below </p>

<img src="img/themandalorianfondg4.jpg">

<h3> Video Editing </h3>
<p> As for video editing, I edit mainly [Music Video], some of the things I know how to do is to color the video, add effects and texts.</p>

<iframe width="500px" height="280px" src="https://www.youtube.com/embed/yaxVQ-vmX3o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>



</div>












</section>









<section class="campus">
<h1> My websites </h1>

<p>  Here are some of my pages </p>


<div class="row2">

<div class="campus-col">
<a href="https://main.sinsatoxp.com">
<img src="img/sinsatoxp2.jpg">

<div class="layer">
<h3> Main Page </h3>

</div>
</a>
</div>

<div class="campus-col">
<a href="https://www.starwarsx.com">
<img src="img/starwars2.jpg">

<div class="layer">
<h3> Star Wars Page </h3>

</div>
</a>
</div>

<div class="campus-col">
<a href="https://www.slimeanime.com">
<img src="img/slimeanime2.jpg">

<div class="layer">
<h3> Slime Anime </h3>

</div>
</a>
</div>





</div>

</section>



<!-- ---------------- facilities -->

<section class="facilities">



<h1> Programms <h1>
<p>  How i do my Websites </p>

<div class="row2">
<div class="facilities-col">

<img src="img/php1.png">
<h3>PHP</h3>
<p  class="phptexx1">  PHP (a recursive initialism for PHP: Hypertext Preprocessor) is an open-source server-side scripting language that can be embedded into HTML 
    to build web applications and dynamic websites. </p>


</div>

<div class="facilities-col" >

<img src="img/css1.png">
<h3> CSS </h3>
<p class="phptexx2">  Cascading Style Sheets (CSS) is a stylesheet language used to describe the presentation of a document written in HTML or XML 
    (including XML dialects such as SVG, MathML or XHTML). CSS describes how elements should be rendered on screen, on paper, 
    in speech, or on other media. </p>


</div>

<div class="facilities-col">

<img src="img/java1.jpg">
<h3> JAVASCRIPT </h3>
<p class="phptexx3"> JavaScript is a scripting or programming language that allows you to implement complex features on web pages — every time a web page does more 
    than just sit there and display static information for you to look at — displaying timely content updates, 
    interactive maps, animated 2D/3D graphics, scrolling video jukeboxes, etc. — you can bet that JavaScript is probably involved. </p>


</div>





</div>


</section>




<!-- ------------------------------- testimonials -->

<section class="testimonials">

<h1> Reviews / Reseñas <h1>
<p>  This are some of the reviews </p>




<div class="row2">


<div class="testimonials-col">
<img src="img/asoka1.jpg">
<div>
    <p> Excelent service, very good ideas and good work </p>


<h3> Ahsoka Tano </h3>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star-o" aria-hidden="true"></i>

</div>
</div>


<div class="testimonials-col">
<img src="img/batman1.jpg">
<div>
    <p> WOW! Muy buen servicio, buenas ideas y buen trabajo </p>


<h3> Batman </h3>

<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star" aria-hidden="true"></i>
<i class="fa fa-star-half-o" aria-hidden="true"></i>


</div>
</div>




</div>


</section>





<!-- -------------------- call to action -->

<section class="cta">

<h1> See my pages <br> anywhere from the World <br> For hire me you can go to Contact Page </h1>



<a href="contact" class="hero-btn"> Contact Me </a>




</section>





@include('layouts.footer')



















</div>
</div>














@include('layouts.cookies')


</body>
        
       
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
   



        
        
        
      
        <script src="{{ asset('js/cookies.js') }}">  </script>

        <script src="{{ asset('js/jquery-3.6.0.min.js') }}">  </script>

        
        <script src="{{ asset('js/jav1.js') }}">  </script>
    
       










</html>



