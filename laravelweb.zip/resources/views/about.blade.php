

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>

    <!-- 2820089612 / GA4 (288142991) -->
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="shortcut icon" href="img/iconsinsa4.png">

    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/about.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
       <link rel="stylesheet" href="{{ asset('css/footer2.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
  <body>


  @include('layouts.topsidebar2')




     


            
<div class="home_content">

<div class="text">
  





<div class="about">
      
            <div class="headerAbout"> 
            
            <h1 class="textwho"> Who i am? </h1>

             <img class="imglog1" src="img/sinsatoxplog1.png" alt="logo sinsatoxp"/>
            
            </div>

  
      
             
<div class="textpart1"> 
            <p class="text1"> I am SinsatoX a programmer and editor, I am managing the entire programming system:<br/></p>

          <!-- <img class="img13slide" src="img/codigo1.jpg" alt="codigos imagen"/>  -->
            
            <div class="text12">        <p id="html1">    HTML</p> <br/> <p id="java1"> JAVACRIPT </p> <br/> <p id="css1"> CSS </p> <br/> <p id="php1">   PHP </p> </div>

            </div>

         
            


<!-- /* ---------------------------------- Img 3d --------------- * -->




<div id="imag3d">






<div class="todboxc1"> 

<div class="todbox"> 

<div class="box2" >


<div class="the-force-box">

<p class="pforce"> </p>




 
</div>






            <div class="card" id="img3d">
<div class="card-character"> 
<div class="card-character-bg" id="cardbg"></div>

            
        

            
                <img class="card-character-img" id="themando1" src="img/laravel1.png" alt="laravel"/>
                 

  

            </div>

           


<div class="card-info">


   
   

        <div>
        <h2 class="card-info-title" id="cardh2title"> PHP / Laravel Programming (3D) </h2>

        <h3 class="card-info-subtitle">  </h3>

        </div>
    
       


<div class="card-info-seasons">




</div>

 </div>



</div>







 </div>
 
 <!-- <div class="card-button2">

<button class="cardb2" type="button" id="buton3"  onclick="img2()" > </button>

</div> -->

 
 </div>

 </div>

 









</div>









<br/> <p class="text2"> I also know about Photoshop, use of Adobe Audition, video editing, among other things. </p>

<img class="img10slide" src="img/photoshop1.png" alt=""/>

<img class="img10slide" src="img/audition1.jpg" alt=""/>

<p class="youcansee1">You can see my pages anywhere<br> from the World</p>


<section class="campus">
<h1 class="h1pages" > My websites </h1>

<p class="pages1">  (Estas son mis paginas) </p>


<div class="row">

<div class="campus-col">
<a href="https://main.sinsatoxp.com">
<img src="img/sinsatoxp2.jpg"/>

<div class="layer">
<h3> Main Page </h3>

</div>
</a>
</div>

<div class="campus-col">
<a href="https://www.starwarsx.com">
<img src="img/starwars2.jpg"/>

<div class="layer">
<h3> Star Wars Page </h3>

</div>
</a>
</div>

<div class="campus-col">
<a href="https://www.slimeanime.com">
<img src="img/slimeanime2.jpg"/>

<div class="layer">
<h3> Slime Anime </h3>

</div>
</a>


</div>

</div>
</section>

<section class="campus2">

<div class="campus-col2">
<a href="https://infopage.sinsatoxp.com">
<img id="imgdirect1"  src="img/prognuev1.jpg"/>

<div class="layer2">
<h3> PHP Page </h3>

</div>
</a>


</div>

<div class="campus-col2">
<a href="https://reactecommerce.sinsatoxp.com">
<img id="imgdirect1" src="img/ecom2.jpg"/>

<div class="layer3">
<h3> Ecommerce ReactJs </h3>

</div>
</a>


</div>


<div class="campus-col2">
<a href="https://reactblog.sinsatoxp.com/">
<img id="imgdirect1" src="img/reactblg1.jpg"/>

<div class="layer3">
<h3> Blog ReactJs </h3>

</div>
</a>


</div>





</section>








<p class="sup1">Thanks for the support </p> <br></br> 













<div class="foterabout">   

@include('layouts.footer')



</div>




</div>



          
</div>







         <div class="cookiesdis">  


@include('layouts.cookies')

</div>


</div>

</body>
        
       
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
  
        
        
        
        
        
      

    






  <script src="js/cookies.js">  </script>

  <script src="js/jav1.js">  </script>

  <script src="js/jav3.js">  </script>
    




</html>




  </body>
  </html>
  


    

  



