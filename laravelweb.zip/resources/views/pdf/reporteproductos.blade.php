<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<style>
*{
margin: 0;
padding: 0;

}


.titulo{
text-align: center;
font:2rem;
color:blue;
margin-bottom: 7%;

}

.thead1{

width: 100%;

}

.trprod{

margin-top: 7%;

}


.theadpart{
margin-bottom: 20%;

color:red
}

</style>
 
</head>
<body>
    <div>

<h1 class="titulo" >Products</h1>

<table class="thead1">
        <thead  > 
                <tr class="theadpart"> 
                        
        <td> Id </td>
        <td> Nombre </td>
        <td> Codigo </td>
        <td> Description </td>
        
        <td> &nbsp; </td> 



                </tr>
        </thead>
<tbody> 
@foreach($productos as $producto)




<tr class="trprod">

        


        <td> {{ $producto->id }} </td>
        <td> {{ $producto->nombre }} </td>
        <td> {{ $producto->codigo }} </td>
        <td> {{ $producto->description }} </td>

        <td> &nbsp; </td>
       



</tr>



@endforeach
</tbody>


</table>

  
</body>
</html>