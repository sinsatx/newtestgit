<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
  <link rel="shortcut icon" href="img/iconsinsa4.png">
  <link rel="stylesheet" href="{{ asset('css/setting.css') }}">
  <title>Document</title>
</head>
<body>
  
@include ('layouts.app')
    
<a href="{{ url('/setting') }}"> <button class="btn btn-success" id="homeback2"> Setting Menu  </button> </a>

<div class="form-grouptotal2"> 


<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="{{ $usuarios->id }}">
</div>





<form action="{{ url('/settingdelete', ['id'=>$usuarios->id]) }}" method="post" id="formEli_{{ $usuarios->id }}">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

@csrf
<div class="form-group" id="deletgroup"> 

<div> Click to Delete Your Account </div>

<button class="btn btn-round btnEliminar" id="btnelimi" data-id="{{$usuarios->id }}" data-toggle="modal" data-target="#ModalEliminar"> Delete Account  </button>


</div>



<input type="hidden" name="id" value="{{ $usuarios->id }}">
<input type="hidden" name="_method" value="delete">

</form> 







                        

                        
      









@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  {{ $message }}     </span>

</div>

@endif


</div>



















</body>



@section('scripts')





<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});







</script>

@endsection

</html>

            