@extends ('layouts.main')

@section('contenido')

 <!-- Page Heading -->
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"> Productos </h1>

                        
                        
                        <div class="col-4"> 
                          
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar">
                            <i class="fas fa-user fa-sm text-white-50"></i> Agregar Producto 
                        </a>


                        <a href="/admin/productos/imprimir" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                            <i class="fas fa-print fa-sm text-white-50"></i> Imprimir
                        </a>

                        </div>

                    </div>

<div class="row">
@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  {{ $message }}     </span>

</div>

@endif
<div class="row col-6">

<canvas id="myChart" width="400" height="400"> </canvas>

</div>

<table class="table col-12 table-responsive">

  <thead>
  <thead>
      <tr> 
        <td> Id </td>
        <td> Nombre </td>
        <td> Codigo </td>
        <td> Description </td>
        <td> Img </td>
        <td> &nbsp; </td> 
      <!-- Un espacio -->
           
      </tr>

      

  </thead>

  <tbody>

        @foreach ($productos as $producto)

        <tr>
        <!-- la variable que use en usercontroller es $usuarios y / as $usuario seria el alias -->

  
        <td> {{ $producto->id }} </td>
        <td> {{ $producto->nombre }} </td>
        <td> {{ $producto->codigo }} </td>
        <td> {{ $producto->description }} </td>
        <td>  <img class="postImg" img src="../img/productos/{{$producto->img}}" width="40%"/>   </td>




        <td>    <button class="btn btn-round btnEliminar" data-id="{{$producto->id }}" data-toggle="modal" data-target="#ModalEliminar"> <i class="fa fa-trash" > </i>     </button>   
  
  <button class="btn btn-round btnEditar" 
  data-id="{{ $producto->id }}" 
  data-name="{{ $producto->nombre }}" 
  data-description="{{ $producto->description }}" 
  data-toggle="modal" data-target="#ModalEditar"> 
  <i class="fa fa-edit" > </i>     </button>    
      
<form action="{{ url('/admin/producto', ['id'=>$producto->id]) }}" method="post" id="formEli_{{ $producto->id }}">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

@csrf



<input type="hidden" name="id" value="{{ $producto->id }}">
<input type="hidden" name="_method" value="delete">

</form> 




      </td> 


  </tr>
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->



      

      <!-- Un espacio -->
      @endforeach
  
  </tbody>


</table>



</div>

<!-- Modal Agregar -->
<div class="modal fade" id="ModalAgregar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar Producto </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/admin/productos" method="post" enctype="multipart/form-data">

@csrf

                <div class="modal-body">
 
                @if($message = Session::get('ErrorInsert')) 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
@foreach($errors->all() as $error)
                       <!-- traigo los errores -->
                                 
        <li> {{ $error }} </li>   


@endforeach

</ul>

</div>

@endif










                


                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="{{ old('nombre') }}" > 


                    </div>

                    <div class="form-group">
                        
<input type="file" class="form-control" name="img" placeholder="Imagen"  >


                    </div>


                    <div class="form-group">
                        
<input type="text" class="form-control"  name="description" placeholder="Description" > 


                    </div>

                    <div class="form-group">
                        
                        <input type="number" class="form-control" name="stock" placeholder="Stock">
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                        <input type="text" class="form-control"  name="codigo" placeholder="Codigo de barras">
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>

    </div>
  </div>
</div>


<!-- Modal Eliminar -->
<div class="modal fade" id="ModalEliminar" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

                <div class="modal-body">
 
                <h5> Desea eliminar el Producto? </h5>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Eliminar</button>
                </div>
  

    </div>
  </div>
</div>


<!-- Modal Editar -->
<div class="modal fade" id="ModalEditar" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Usuario</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/admin/usuarios/edit" method="post">

@csrf

                <div class="modal-body">
 
                @if($message = Session::get('ErrorInsert')) 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
@foreach($errors->all() as $error)
                       <!-- traigo los errores -->
                                 
        <li> {{ $error }} </li>   


@endforeach

</ul>

</div>

@endif










                

<input type="hidden" name="id" id="idEdit">
                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="{{ old('nombre') }}" id="nameEdit" > 


                    </div>

                    <div class="form-group">
                        
<input type="email" class="form-control" name="email" placeholder="Email"  value="{{ old('email') }}" id="emailEdit" >


                    </div>

                    <div class="form-group">
                        
                        <input type="password" class="form-control" name="pass1" placeholder="Password">
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                        <input type="password" class="form-control"  name="pass2" placeholder="Confirmar Password">
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>

    </div>
  </div>
</div>



@endsection


@section('scripts')

@if($message = Session::get('ErrorInsert'))

    

       

<script> 

$(document).ready(function(){
        

  $("#ModalAgregar").modal('show');   //este code es del lado del servidor si hay un error se ejecuta esto

    });







</script>


@endif






@endsection
