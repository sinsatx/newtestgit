

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="{{ asset('css/programming.css') }}">
<!-- <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}"> -->
    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="stylesheet" href="{{ asset('css/singlepost.css') }}">
   
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  @include('layouts.topsidebar2')


     


            
<div class="home_content">

<div class="text">



@foreach ($productos as $producto)

 
<div class="singlePost">
            
            
            <div class="singlePostWrapper">

                <img class="singlePostImg" src="../img/productos/{{$producto->img}}" alt=""/>

<h1 class="singlePostTitle">
{{ $producto->nombre }} 
<div class="singlePostEdit">
<!-- <i class="singlePostIcon fa fa-edit"></i>


<i class="singlePostIcon fa fa-remove"></i> -->


</div>

</h1>
<div class="singlePostInfo">


<span class="singlePostAuthor">Author: <b>SinsatoXP</b></span>
<span class="singlePostDate"> {{ $producto->stock }} </span>
    
</div>
<p class="singlePostDesc">{{ $producto->description }}</p>

            </div>

        </div>

@endforeach






<div class="form-grouptotal3">   


<h3>Creat Comment</h3>


<form   action="{{ route('logincoment-create') }}"  method="POST">
@csrf

 <div class="form-group"> 

<input type="hidden"  name="id" id="name" >
</div> 

@if (Route::has('login'))

@auth

<div class="form-group" id="form-name1"> 
<label for="name">User:</label>
<input type="text"  name="user_id" id="name" class="user1" value="{{ Auth::user()->id }}"  placeholder="User">
</div>

@else

@endauth

@endif

@foreach($productos  as  $producto)

<div class="form-group" id="form-name1"> 
<label for="name">post_id:</label>
<input type="text"  name="post_id" id="name" class="user1" value="{{ $producto->id }}"  placeholder="User">
</div>


@endforeach

<div class="comment2">  
<label for="name" >Comment</label>
<div class="form-group" id="form-name1"> 

<textarea type="text" name="comment" id="name" class="tx1" placeholder="Comment" rows="6" cols="30"></textarea>
</div>
</div>

<button type="submit" class="btn btn-success">Post</button>

</form>





</div>







@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  {{ $message }}     </span>

</div>

@endif







<div class="form-grouptotal6"> 

<h1>Comments</h1>

</div>
       

 <!-- le agrege el $post -->

@foreach($productos->comentariologins  as  $comentariologin)


<div class="form-grouptotal4">   





<div class="form-group"> 

<input type="text"  name="id" id="name" value="{{ $comentariologin->id }}">
</div>





<div class="form-group"> 
<label for="name" class="lab1">User: </label>
{{ $comentariologin->user_id }}
</div>

<div class="form-group"> 
<label for="name" class="lab1">Post_id: </label>
{{ $comentariologin->post_id }}
</div>

<div class="form-group"> 
<label for="name"  class="lab2">Comment: </label>
 <div class="comentar1">  {{ $comentariologin->comment }}</div> 
</div>



</div>




@endforeach





</div>












</div>








</div>


</div>






@include('layouts.cookies')


</body>
        
       
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    
















  </body>
  </html>
  


    

  








