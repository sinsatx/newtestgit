

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="{{ asset('css/programming.css') }}">
 <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}"> 
    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="shortcut icon" href="img/iconsinsa4.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>


  @include('layouts.topsidebar2')





 <!-- Page Heading -->
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"> Productos </h1>

                        
                        
                        <div class="col-4"> 
                          
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar">
                            <i class="fas fa-user fa-sm text-white-50"></i> Agregar Producto 
                        </a>


                        <a href="/admin/productos/imprimir" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                            <i class="fas fa-print fa-sm text-white-50"></i> Imprimir
                        </a>

                        </div>

                    </div>

<div class="row">
@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  {{ $message }}     </span>

</div>

@endif


@if($message = Session::get('alertd'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  {{ $message }}     </span>

</div>

@endif


@forelse($productos as $producto)
@empty
<p class="text-center">

No results found for: <strong> {{ request()->query('search')}} </strong>

</p>
@endforelse









<!-- <div class="row col-6">

<canvas id="myChart" width="400" height="400"> </canvas>

</div> -->

<table class="table col-12 table-responsive">

  <thead>
  <thead>
      <tr> 
        <td> Id </td>
        <td> Nombre </td>
        <td> Codigo </td>
        <td> Description </td>
        <td> Img </td>
        <td> &nbsp; </td> 
      <!-- Un espacio -->
           
      </tr>

      

  </thead>

  <tbody>

        @foreach ($productos as $producto)

        <tr>
        <!-- la variable que use en usercontroller es $usuarios y / as $usuario seria el alias -->

  
        <td> {{ $producto->id }} </td>
        <td> {{ $producto->nombre }} </td>
        <td> {{ $producto->codigo }} </td>
        <td> {{ $producto->description }} </td>
        <td>  <img class="postImg" img src="../img/productos/{{$producto->img}}" width="40%"/>   </td>




        <td>    <button class="btn btn-round btnEliminar" data-id="{{$producto->id }}" data-toggle="modal" data-target="#ModalEliminar"> <i class="fa fa-trash" > </i>     </button>   
  
  <button class="btn btn-round btnEditar" 
  data-id="{{ $producto->id }}" 
  data-nombre="{{ $producto->nombre }}" 
  data-codigo="{{ $producto->codigo }}" 
  data-stock="{{ $producto->stock }}" 
  data-description="{{ $producto->description }}"
  data-img="{{ $producto->img }}"
  data-toggle="modal" data-target="#ModalEditar"> 
  <i class="fa fa-edit" > </i>     </button>    
      
<form action="{{ url('/admin/productos', ['id'=>$producto->id]) }}" method="post" id="formEli_{{ $producto->id }}">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

@csrf



<input type="hidden" name="id" value="{{ $producto->id }}">
<input type="hidden" name="_method" value="delete">

</form> 




      </td> 


  </tr>
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->



      

      <!-- Un espacio -->
      @endforeach
  
  </tbody>


</table>

<span>  
{{$productos->links()}}

</span>


</div>

<!-- Modal Agregar -->
<div class="modal fade" id="ModalAgregar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar Producto </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/admin/productos" method="post" enctype="multipart/form-data">

@csrf

                <div class="modal-body">
 
                @if($message = Session::get('ErrorInsert')) 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
@foreach($errors->all() as $error)
                       <!-- traigo los errores -->
                                 
        <li> {{ $error }} </li>   


@endforeach

</ul>

</div>

@endif










                


                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="{{ old('nombre') }}" > 


                    </div>

                    <div class="form-group">
                        
<input type="file" class="form-control" name="img" placeholder="Imagen"  >


                    </div>


                    <div class="form-group">
                        
<textarea type="text" class="form-control"  name="description" placeholder="Description" > </textarea>


                    </div>

                    <div class="form-group">
                        
                        <input type="number" class="form-control" name="stock" placeholder="Numero">
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                        <input type="text" class="form-control"  name="codigo" placeholder="Codigo">
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>

    </div>
  </div>
</div>


<!-- Modal Eliminar -->
<div class="modal fade" id="ModalEliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

                <div class="modal-body">
 
                <h5> Desea eliminar el Producto? </h5>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Eliminar</button>
                </div>
  

    </div>
  </div>
</div>


<!-- Modal Editar -->
<div class="modal fade" id="ModalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/admin/productos/edit" method="post"  enctype="multipart/form-data">

@csrf

                <div class="modal-body">
 
                @if($message = Session::get('ErrorInsert')) 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
@foreach($errors->all() as $error)
                       <!-- traigo los errores -->
                                 
        <li> {{ $error }} </li>   


@endforeach

</ul>

</div>

@endif










                

<input type="hidden" name="id" id="idEdit">
                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="{{ old('nombre') }}" id="nombreEdit" > 


                    </div>

                    <div class="form-group">
                        
<input type="text" class="form-control" name="codigo" placeholder="Codigo"  value="{{ old('codigo') }}" id="codigoEdit" >


                    </div>

                    <div class="form-group">

                    <input type="number" class="form-control" name="stock" placeholder="Numero" value="{{ old('stock') }}" id="stockEdit" >

                    </div>

                    <div class="form-group">
                        
                        <textarea type="text" class="form-control" name="description" placeholder="description" value="{{ old('description') }}" id="descriptionEdit"> </textarea>
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                                            <input type="file" class="form-control" name="img" placeholder="Imagen" id="imgEdit" value="{{ old('img') }}">
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>

    </div>
  </div>
</div>


@endif




@if($message = Session::get('ErrorInsert'))

    

       

<script> 

$(document).ready(function(){
        

  $("#ModalAgregar").modal('show');   //este code es del lado del servidor si hay un error se ejecuta esto

    });







</script>


@endif


<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});

$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('nombre')); // el name le puse al atributo / data-name
$("#codigoEdit").val($(this).data('codigo'));
$("#stockEdit").val($(this).data('stock'));
$("#descriptionEdit").val($(this).data('description'));
$("#imgEdit").val($(this).data('img'));


});

</script>










@endsection



</div>


</div>






@include('layouts.cookies')


</body>
        
       
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    
















  </body>
  </html>
  


    
