
<!-- ------------------------- footer -->


<div class="footer">




<div class="left"> 

<p class="logo"> SinsatoXP </p>

<p class="desc"> I am SinsatoX a programmer and editor </p>






<div class="socialicons1">
    
    
    
    
<a href="https://www.youtube.com/sinsato">   <i class="topIcon1 fa fa-youtube"></i> </a> 
        <a href="https://www.instagram.com/lucasmester1">    <i class="topIcon2 fa fa-instagram"></i></a>
        <a href="mailto:sinsatoxp1@gmail.com">     <i class="topIcon3 fa fa-envelope-o"></i> </a>
        <a href="https://main.sinsatoxp.com">    <i class="topIcon4 fa fa-chrome"></i> </a>
            
    
    
     </div>

     </div>





<div class="center"> 





<div class="privacy"> 


<a class="link" href="/cookies" >

Cookies Advice


</a>
</div>


<div class="privacy2"> 

Term of Use


</div>


<div class="privacy2"> 

All Rights Reserved


</div>


 </div>




     

<div class="right">

<div class="contact2"> 

<p class="location1"> Location: Argentina, Buenos Aires </p>


<p class="number1"> Phone: +XX XXXXXXXXX </p>

<p class="email2"> Email: sinsatoxp1@gmail.com</p>


</div>



</div>






            
       

</div>