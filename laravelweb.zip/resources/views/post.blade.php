

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="{{ asset('css/programming.css') }}">
 <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="stylesheet" href="{{ asset('css/singlepost.css') }}">
   
    <link rel="shortcut icon" href="../img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  @include('layouts.topsidebar2')


     


            
<div class="home_content">

<div class="text">









<div class="postsextras">


<h3 class="postlat"> Posts </h3>


@foreach ($latestPosts as $posts)

<div class="todopost"> 

<div class="imgposts"> 
<a href="{{route('posts.show',$posts)}} "> 

<img   src="/img/productos/{{$posts->img}}"/>  

</a>

</div>

<div class="postnombre"> 

<a class="linkpostnombre" href="{{route('posts.show',$posts)}}" > {{ $posts->nombre }}  </a> 

</div>

</div>




@endforeach





</div>

@foreach ($productos as $producto)

 
<div class="singlePost">


            
            
            <div class="singlePostWrapper">


            

                <img class="singlePostImg" src="../img/productos/{{$producto->img}}" alt=""/>

                

<h1 class="singlePostTitle">
{{ $producto->nombre }} 



<div class="singlePostEdit">
<!-- <i class="singlePostIcon fa fa-edit"></i>


<i class="singlePostIcon fa fa-remove"></i> -->


</div>

@foreach ($productos as $producto)

@if(Auth::id() == $producto->userpost_id )

 <div class="btnedit2"> 

<a href="{{route('postcom.show',$producto) }}">

<button class="btn btn-success btnEditar btnEdit"> 
<i class="fa fa-edit" > </i>     </button>

</a>

<a href="{{route('postcom.show',$producto) }}">

<button class="btn btn-danger btnEliminar modal-btn1" id="btnelimi">  <i class="fa fa-trash" >   </i>  </button>

</a>

</div>

@endif

@endforeach



</h1>
<div class="singlePostInfo">


<span class="singlePostAuthor">Author: <b>{{ $producto->author }}</b></span>
<span class="singlePostDate"> {{ $producto->id }} </span>
    
</div>
<p class="singlePostDesc">{{ $producto->description }}</p>


<p> Tags: {{ $producto->codigo }}</p>

            </div>

        </div>

@endforeach







<div class="form-grouptotal3" id="form-grouptotal3post">   


<h3>Creat Comment</h3>


<form   action="{{ route('logincoment-create') }}"  method="POST">
@csrf

 <div class="form-group"> 

<input type="hidden"  name="id" id="name" >
</div> 




@if (Route::has('login'))

@auth



<input type="hidden"  name="user_id" id="name" class="user1" value="{{ Auth::user()->id }}"  placeholder="User">




@foreach($productos  as  $producto)


<input type="hidden"   name="id" id="name" class="user1" value="{{ $producto->id }}"  placeholder="User">



@endforeach

@else

@endauth

@endif


<div class="comment2">  

<div class="form-group" id="form-name1"> 

<textarea type="text" name="comment" id="name" class="tx1" placeholder="Login to Comment" rows="6" cols="30"></textarea>
</div>
</div>

<button type="submit" class="btn btn-success">Post</button>

</form>





</div>







@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  {{ $message }}     </span>

</div>

@endif







<div class="form-grouptotal6" id="form-grouptotal6post"> 

<h1>Comments</h1>

</div>
       

 <!-- le agrege el $post -->

@foreach($comentariologins  as  $comentariologin)





<div class="form-grouptotal4" id="form-grouptotalpost4">   





<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="{{ $comentariologin->id }}">
</div>





<div class="form-group"> 
<label for="name" class="lab1">User: </label>
{{ $comentariologin->usuario->name }}






<img src="{{asset('users/'.$comentariologin->usuario->img)}}" id="imguser1" alt="">

</div>



<div class="form-group"> 
<label for="name"  class="lab2">{{ $comentariologin->edit }} Comment: </label>
 <div class="comentar1">  {{ $comentariologin->comment }}</div> 
</div>



<!-- --------------------------- -->




@if(Auth::id() == $comentariologin->user_id )

<div> 

<a href="{{route('comment.show',$comentariologin) }}">

<button class="btn btn-success btnEditar btnEdit" 

data-id="{{ $comentariologin->id }}" 
data-ids="{{ $comentariologin->ids }}" 
data-user_id="{{ $comentariologin->user_id }}" 

data-comment="{{ $comentariologin->comment }}"

data-toggle="modal" data-target="#ModalEditar" id="btnedit"  class="modal-bot1" > 
<i class="fa fa-edit" > </i>     </button>

</a>


<a href="{{route('comment.show',$comentariologin) }}">
<button class="btn btn-danger btnEliminar modal-btn1" id="btnelimi" data-id="{{$comentariologin->ids }}" data-toggle="modal" data-target="#ModalEliminar">  <i class="fa fa-trash" >   </i>  </button>

</a>

</div>

@endif









</div>




@endforeach









<div class="postsextras2">


<h3 class="postlat2"> Posts </h3>


@foreach ($latestPosts as $posts)

<div class="todopost2"> 

<div class="imgposts2"> 
<a href="{{route('posts.show',$posts)}} "> 

<img   src="/img/productos/{{$posts->img}}"/>  

</a>

</div>

<div class="postnombre2"> 

<a class="linkpostnombre2" href="{{route('posts.show',$posts)}}" > {{ $posts->nombre }}  </a> 

</div>

</div>




@endforeach





</div>


















</div>



</div>











@include('layouts.cookies')





</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>


var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});






$(".btnEditar").click(function(){

  $("#idEdit").val($(this).data('id'));

$("#idsEdit").val($(this).data('ids'));

$("#nombreEdit").val($(this).data('user_id')); // el name le puse al atributo / data-name



$("#descriptionEdit").val($(this).data('comment'));



});






</script>


<script>


var modalBtn = document.querySelector('.modal-btn1');
var modalBg = document.querySelector('.modal-bg1');
var modalClose = document.querySelector('.modal-close1');


modalBtn.addEventListener('click',function(){

modalBg.classList.add('bg-active');

});


modalClose.addEventListener('click',function(){

modalBg.classList.remove('bg-active');

});




</script>















       
        
        
        <script src="../js/cookies.js">  </script>
    
        
        
      

    

















  </html>
  


    

  








