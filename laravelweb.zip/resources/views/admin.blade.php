
@extends ('layouts.main')

@section('contenido')

@if(Auth::user()->nivel == 'admin')

<iframe width="600" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSpAjueFHXbiATf4SYKab8_EAfw-HB6aCruchX5-hvK8Mc3qN-FJK_h5ryTnT89Vqq0xpsimR-qJolZ/pubchart?oid=2106040376&amp;format=interactive"></iframe>

    <iframe width="600" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSpAjueFHXbiATf4SYKab8_EAfw-HB6aCruchX5-hvK8Mc3qN-FJK_h5ryTnT89Vqq0xpsimR-qJolZ/pubchart?oid=1231176533&amp;format=interactive"></iframe>

        <iframe width="600" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSpAjueFHXbiATf4SYKab8_EAfw-HB6aCruchX5-hvK8Mc3qN-FJK_h5ryTnT89Vqq0xpsimR-qJolZ/pubchart?oid=1501793482&amp;format=interactive"></iframe>

            <iframe width="600" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSpAjueFHXbiATf4SYKab8_EAfw-HB6aCruchX5-hvK8Mc3qN-FJK_h5ryTnT89Vqq0xpsimR-qJolZ/pubchart?oid=1824819580&amp;format=interactive"></iframe>

@endif



@if(Auth::user()->nivel == 'usuario')

<h1> User Page </h1>

@endif





@endsection