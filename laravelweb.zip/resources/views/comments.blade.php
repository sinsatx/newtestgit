
@extends ('layouts.main')


@section('contenido')

@if(Auth::user()->nivel == 'admin')

<div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"> Comments </h1>

                        




<a href="#" class=" d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar" onclick="comentarioadd()">
                            <i class="fas fa-user fa-sm text-white-50"></i> Add Comment
                        </a>

                        <a href="#" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar" onclick="comentarioadd2()">
                            <i class=" fa-sm text-white-50" ></i> Hide Add Comment
                        </a>


                        



</div>




@forelse($comentarios as $comentario)
@empty
<p class="text-center">

No results found for: <strong> {{ request()->query('search')}} </strong>

</p>
@endforelse


<div id="addcomentario" class="form-grouptotal3">   


<h1>Creat Comment</h1>


<form   action="{{ route('coment-create') }}"  method="POST">
@csrf

 <div class="form-group"> 

<input type="hidden"  name="id" id="name" >
</div> 


<div class="form-group" id="form-name1"> 
<label for="name">User</label>
<input type="text"  name="user" id="name" >
</div>

<label for="name">Comment</label>
<div class="form-group" id="form-name1"> 

<textarea type="text"  name="descripcion" id="name" cols="30" rows="7"></textarea>
</div>


<button type="submit" class="btn btn-success">Creat Comment</button>

</form>





</div>





<table class="table col-12 table-responsive">


  <thead>
  

      <tr> 
        <td> Id </td>
        <td> User </td>
        <td> Description </td>
        <td> &nbsp; </td> 
      <!-- Un espacio -->
           
      </tr>

      


  </thead>



  <tbody>


  @foreach($comentarios as $comentario)

<tr id="td2"> 







<td>   {{ $comentario->id }} </td>

<td> {{ $comentario->user }} </td>


<div > 
<td class="desc2"> {{ $comentario->descripcion }} </td>


</div>


<td >   



  <button class="btn btn-success btnEditar" 
  data-id="{{ $comentario->id }}" 
  data-user="{{ $comentario->user }}" 

  data-descripcion="{{ $comentario->descripcion }}"
  
  data-toggle="modal" data-target="#ModalEditar"> 
  <i class="fa fa-edit" > </i>     </button>    
      
  <button class="btn btn-danger btnEliminar" id="btnelimi" data-id="{{$comentario->id }}" data-toggle="modal" data-target="#ModalEliminar">  <i class="fa fa-trash" >   </i>  </button>



  <div class="botsepar1">  


  <form action="{{ route('coment-delete') }}" method="post" id="formEli_{{ $comentario->id }}">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

@csrf






<input type="hidden" name="id" value="{{ $comentario->id }}">
<input type="hidden" name="_method" value="delete">

</form>

</div>

      </td> 


</tr>


@endforeach

  </tbody>

</table>









@foreach($comentarios as $comentario)

<div class="form-grouptotal">   
















 
<!-- Modal Editar -->
<div class="modal fade" id="ModalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Comment Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     
<form action="{{ route('coment-update') }}"  method="POST" enctype="multipart/form-data">

@csrf
@method('PUT')


                <div class="modal-body">
 
                @if($message = Session::get('ErrorInsert')) 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
@foreach($errors->all() as $error)
                       <!-- traigo los errores -->
                                 
        <li> {{ $error }} </li>   


@endforeach

</ul>

</div>

@endif









                

<input type="hidden" name="id" id="idEdit" value="{{ $comentario->id }}">
                
                    <div class="form-group">

<input type="text" class="form-control" name="user" placeholder="Nombre"  value="{{ $comentario->user }}" id="nombreEdit" > 


                    </div>

                  

                    <div class="form-group">
                        
                        <textarea type="text" placeholder="description" class="form-control" name="descripcion" value="{{ $comentario->descripcion }}" id="descriptionEdit"></textarea>
                        
                        
                                            </div>

                                   

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
      </form>

    </div>
  </div>
</div>










</div>



<!-- Modal Eliminar -->
<div class="modal fade" id="ModalEliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Comment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

                <div class="modal-body">
 
                <h5> Do you want to delete the comment? </h5>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Delete</button>
                </div>
  

    </div>
  </div>
</div>









<!-- <a href="{{ url('/') }}"> <button class="btn btn-success" id="homeback"> Home  </button> </a> -->


@endforeach


@if($message = Session::get('Listo'))  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  {{ $message }}     </span>

</div>

@endif



<span>  
{{$comentarios->links()}}

</span>

@endif


@if(Auth::user()->nivel == 'usuario')

<h1> User Page </h1>

@endif





@endsection


@section('scripts')

<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});

$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('user')); // el name le puse al atributo / data-name

$("#descriptionEdit").val($(this).data('descripcion'));



});

</script>


<script>

function  comentarioadd(){

document.getElementById('addcomentario').style.display = 'block';
//poner todos los demas que aparecen en none para que se oculten

}

function  comentarioadd2(){

document.getElementById('addcomentario').style.display = 'none';
//poner todos los demas que aparecen en none para que se oculten

}








</script>




<script src="{{ asset('../js/jquery-ui.js') }}">  </script>
        
      
        <script>
        
        
      
        $('#search').autocomplete({
        
        source: function(request, response){
$.ajax({

url: "{{route('search.commentwithoutlog')}}",
dataType: 'json',
data: {
term: request.term

},

success: function(data){

response(data)

} 


});


        }
        
        });
        
        
        
        
        
        
        
        
        
        </script>





@endsection



            