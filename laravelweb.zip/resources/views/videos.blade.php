

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="{{ asset('css/videos.css') }}">
<!-- <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}"> -->
    <link rel="stylesheet" href="{{ asset('css/topsidebar2.css') }}">
    <link rel="stylesheet" href="{{ asset('css/stylebody.css') }}">
    <link rel="stylesheet" href="{{ asset('css/cookies.css') }}">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link rel="shortcut icon" href="img/iconsinsa4.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<style>




</style>


<body>


  @include('layouts.topsidebar2')


     
  

            
<div class="home_content">

<div class="text">



<h1 class="amv1"> Anime Music Video (AMV) </h1>

<iframe  src="https://www.youtube.com/embed/2h6CoWR23EM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

  <iframe  src="https://www.youtube.com/embed/3Ox6vLryT6Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


    <iframe  src="https://www.youtube.com/embed/4qqkzE0Croc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h1 class="mmv1"> Movie Music Video (MMV) </h1>


<iframe src="https://www.youtube.com/embed/yaxVQ-vmX3o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

  <iframe  src="https://www.youtube.com/embed/t4fUL5xp_WY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

    <iframe src="https://www.youtube.com/embed/V6hZubQXqF0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>



<h1 class="gmv1"> Game Music Video (GMV) </h1>

<iframe  src="https://www.youtube.com/embed/pD0CFQQWStA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

  <iframe  src="https://www.youtube.com/embed/6fTpD8YaDDU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

    <iframe  src="https://www.youtube.com/embed/geNKtgXAwLk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

    
<h1 class="smv1"> Serie Music Video (SMV) </h1>

<iframe  src="https://www.youtube.com/embed/ERCLAM8SUvw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

  <iframe  src="https://www.youtube.com/embed/voqrDHlEXG0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe src="https://www.youtube.com/embed/NwVgikt4NRQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
















</div>


</div>






@include('layouts.cookies')


</body>
        
       
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    
















  </body>
  </html>
  


    

  








