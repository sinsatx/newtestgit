

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="<?php echo e(asset('css/programming.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylebody.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/singlepost.css')); ?>">
   
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     


            
<div class="home_content">

<div class="text">


                        

                

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  Your Post is deleted     </span>

</div>












</div>




</div>












<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});


$(".btnEditar").click(function(){

  $("#idEdit").val($(this).data('id'));

$("#idsEdit").val($(this).data('ids'));

$("#nombreEdit").val($(this).data('user_id')); // el name le puse al atributo / data-name



$("#descriptionEdit").val($(this).data('comment'));



});



// function  editcomment(){

// document.getElementsByClassName('editcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('deletcom').style.display = 'none';
// }

// function  deletecomment(){

// document.getElementsByClassName('deletcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('editcom').style.display = 'none';
// }


</script>


















       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    

        
  </html>
  


    



<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/postdeleteconfirm.blade.php ENDPATH**/ ?>