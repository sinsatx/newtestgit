   
  

    

  <?php $__env->startSection('content2'); ?>

   


          
<div class="home_content">

<div class="text">This is a  Test: - Admin Login-  User: admin@email.com  / Password: 123

              <a href="https://laravelxsweb.sinsatoxp.com/admin"> Admin View </a>

<br> 

Normal user: test@email.com / Password: 123

                    </div>


<img src="img/laravel1.png" alt="laravel"/>




</div>



          <?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.hometopsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/home.blade.php ENDPATH**/ ?>