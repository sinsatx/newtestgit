<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  <link rel="shortcut icon" href="img/iconsinsa4.png">
  <link rel="stylesheet" href="<?php echo e(asset('css/setting.css')); ?>">
  <title>Document</title>
</head>
<body>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<a href="<?php echo e(url('/setting')); ?>"> <button class="btn btn-success" id="homeback2"> Setting Menu  </button> </a>
    
<div class="form-grouptotal2">  



<form action="<?php echo e(route('users.update-profile')); ?>"  method="POST" enctype="multipart/form-data">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>



<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="<?php echo e($usuarios->id); ?>">
</div>


<div class="form-group" id="form-name1"> 
<label for="name">Name</label>
<input type="text"  name="name" id="name" value="<?php echo e($usuarios->name); ?>">
</div>

<!-- <div class="form-group"> 
<label for="name">Password</label>
<input type="password"  name="password" id="name" value="">
</div> -->



                        
 <input type="file" class="form-control" name="img" value="" placeholder="Imagen"  id="imgform">
                        
           
 <img src="<?php echo e(asset('users/'.Auth::user()->img)); ?>" name="img" alt="">
      


<button type="submit" class="btn btn-success">Update Profile</button>




</form>  




<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>



</div>


















</body>
</html>

            <?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/settingprofile.blade.php ENDPATH**/ ?>