<?php $__env->startSection('contenido'); ?>

<?php if(Auth::user()->nivel == 'admin'): ?>



<div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"> Comments </h1>

                        





                        



</div>






<table class="table col-12 table-responsive">


  <thead>
  

      <tr> 
        <td> Id </td>
        <td> User Name </td>
        <td> Post Name </td>
        <td> Comment </td>
        <td> &nbsp; </td> 
      <!-- Un espacio -->
           
      </tr>

      


  </thead>



  <tbody>


  <?php $__currentLoopData = $comentariologins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentariologin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr id="td2"> 







<td>   <?php echo e($comentariologin->ids); ?> </td>

<td> <?php echo e($comentariologin->usuario->name); ?> </td>

<td>   <?php echo e($comentariologin->producto->nombre); ?> </td>


<div > 
<td class="desc2"> <?php echo e($comentariologin->comment); ?> </td>


</div>



<td >   



  <button class="btn btn-success btnEditar" 

  data-id="<?php echo e($comentariologin->id); ?>" 
  data-ids="<?php echo e($comentariologin->ids); ?>" 
  data-user_id="<?php echo e($comentariologin->user_id); ?>" 
  data-edit="<?php echo e($comentariologin->edit); ?>" 
  data-comment="<?php echo e($comentariologin->comment); ?>"
  
  data-toggle="modal" data-target="#ModalEditar"> 
  <i class="fa fa-edit" > </i>     </button>    
      
  <button class="btn btn-danger btnEliminar" id="btnelimi" data-id="<?php echo e($comentariologin->ids); ?>" data-toggle="modal" data-target="#ModalEliminar">  <i class="fa fa-trash" >   </i>  </button>



  <div class="botsepar1">  


  <form action="<?php echo e(route('logincoment-delete')); ?>" method="post" id="formEli_<?php echo e($comentariologin->ids); ?>">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

<?php echo csrf_field(); ?>






<input type="hidden" name="id" value="<?php echo e($comentariologin->ids); ?>">
<input type="hidden" name="_method" value="delete">

</form>

</div>

      </td> 


</tr>


<!-- Modal Eliminar -->
<div class="modal fade" id="ModalEliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Comment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

                <div class="modal-body">
 
                <h5> Do you want to delete the comment? </h5>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Delete</button>
                </div>
  

    </div>
  </div>
</div>





<div class="form-grouptotal">   
















 
<!-- Modal Editar -->
<div class="modal fade" id="ModalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Comment Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     
<form action="<?php echo e(route('logincoment-update')); ?>"  method="POST" enctype="multipart/form-data">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>


                <div class="modal-body">
 
                <?php if($message = Session::get('ErrorInsert')): ?> 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <!-- traigo los errores -->
                                 
        <li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>







<div class="form-group">

<input type="hidden"  name="id" id="idEdit" value="<?php echo e($comentariologin->id); ?>"> 

</div>

<div class="form-group">

<input type="hidden"  name="ids" id="idsEdit" value="<?php echo e($comentariologin->ids); ?>">



</div>
                
                    <div class="form-group">

<input type="hidden" class="form-control" name="user_id" placeholder="User_id"  value="<?php echo e($comentariologin->user_id); ?>" id="nombreEdit" > 


                    </div>

                    <div class="form-group">

<input type="hidden" class="form-control" name="edit" placeholder="edit"  value="(edited)" id="editedEdit" > 


                    </div>


                  
                  

                    <div class="form-group">
                        
                        <textarea type="text" placeholder="Comment" class="form-control" name="comment" value="<?php echo e($comentariologin->comment); ?>" id="descriptionEdit"></textarea>
                        
                        
                                            </div>

                                            

                                   

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
      </form>

    </div>
  </div>
</div>










</div>












<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>

</table>








<?php endif; ?>


<?php if(Auth::user()->nivel == 'usuario'): ?>

<h1> User Page </h1>

<?php endif; ?>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});

$(".btnEditar").click(function(){

  $("#idEdit").val($(this).data('id'));

$("#idsEdit").val($(this).data('ids'));

$("#editdEdit").val($(this).data('edit'));

$("#nombreEdit").val($(this).data('user_id')); // el name le puse al atributo / data-name



$("#descriptionEdit").val($(this).data('comment'));



});

</script>


<script>

function  comentarioadd(){

document.getElementById('addcomentario').style.display = 'block';
//poner todos los demas que aparecen en none para que se oculten

}

function  comentarioadd2(){

document.getElementById('addcomentario').style.display = 'none';
//poner todos los demas que aparecen en none para que se oculten

}








</script>








<script src="<?php echo e(asset('../js/jquery-ui.js')); ?>">  </script>
        
      
        <script>
        
        
      
        $('#search').autocomplete({
        
        source: function(request, response){
$.ajax({

url: "<?php echo e(route('search.commentlog')); ?>",
dataType: 'json',
data: {
term: request.term

},

success: function(data){

response(data)

} 


});


        }
        
        });
        
        
        
        
        
        
        
        
        
        </script>




<?php $__env->stopSection(); ?>



            
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/commentlogins.blade.php ENDPATH**/ ?>