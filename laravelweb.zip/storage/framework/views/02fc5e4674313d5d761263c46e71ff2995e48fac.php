<div class="container">
     <div class="row justify-content-center">
         <div class="col-md-8">
             <div class="card">
                 <div class="card-header"> </div>
                   <div class="card-body">
                    <?php if(session('resent')): ?>
                         <div class="alert alert-success" role="alert">


                            <?php echo e(__('A new email has been sent to your email')); ?>


                            
                        </div>
                    <?php endif; ?>
                    <?php echo $content; ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/email-template.blade.php ENDPATH**/ ?>