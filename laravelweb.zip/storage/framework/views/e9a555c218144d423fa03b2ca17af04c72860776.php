<?php $__env->startSection('contenido'); ?>

<?php if(Route::has('login')): ?>

<?php if(auth()->guard()->check()): ?>

 <!-- Page Heading -->
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"> Productos </h1>

                        
                        
                        <div class="col-4"> 
                          
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar">
                            <i class="fas fa-user fa-sm text-white-50"></i> Agregar Producto 
                        </a>


                        <a href="/admin/productos/imprimir" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                            <i class="fas fa-print fa-sm text-white-50"></i> Imprimir
                        </a>

                        </div>

                    </div>

<div class="row">
<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


<?php if($message = Session::get('alertd')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


<?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p class="text-center">

No results found for: <strong> <?php echo e(request()->query('search')); ?> </strong>

</p>
<?php endif; ?>









<!-- <div class="row col-6">

<canvas id="myChart" width="400" height="400"> </canvas>

</div> -->

<table class="table col-12 table-responsive">

  <thead>
  <thead>
      <tr> 
        <td> Id </td>
        <td> Nombre </td>
        <td> Codigo </td>
        <td> Description </td>
        <td> Img </td>
        <td> &nbsp; </td> 
      <!-- Un espacio -->
           
      </tr>

      

  </thead>

  <tbody>

        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
        <!-- la variable que use en usercontroller es $usuarios y / as $usuario seria el alias -->

  
        <td> <?php echo e($producto->id); ?> </td>
        <td> <?php echo e($producto->nombre); ?> </td>
        <td> <?php echo e($producto->codigo); ?> </td>
        <td> <?php echo e($producto->description); ?> </td>
        <td>  <img class="postImg" img src="../img/productos/<?php echo e($producto->img); ?>" width="40%"/>   </td>




        <td>    <button class="btn btn-round btnEliminar" data-id="<?php echo e($producto->id); ?>" data-toggle="modal" data-target="#ModalEliminar"> <i class="fa fa-trash" > </i>     </button>   
  
  <button class="btn btn-round btnEditar" 
  data-id="<?php echo e($producto->id); ?>" 
  data-nombre="<?php echo e($producto->nombre); ?>" 
  data-codigo="<?php echo e($producto->codigo); ?>" 
  data-admin="<?php echo e($producto->admin); ?>" 
  data-author="<?php echo e($producto->author); ?>" 
  data-stock="<?php echo e($producto->stock); ?>" 
  data-slug="<?php echo e($producto->slug); ?>" 
  data-description="<?php echo e($producto->description); ?>"
  data-img="<?php echo e($producto->img); ?>"
  data-toggle="modal" data-target="#ModalEditar"> 
  <i class="fa fa-edit" > </i>     </button>    
      
<form action="<?php echo e(url('/admin/productos', ['id'=>$producto->id])); ?>" method="post" id="formEli_<?php echo e($producto->id); ?>">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

<?php echo csrf_field(); ?>



<input type="hidden" name="id" value="<?php echo e($producto->id); ?>">
<input type="hidden" name="_method" value="delete">

</form> 




      </td> 


  </tr>
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->



      

      <!-- Un espacio -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  </tbody>


</table>

<span>  
<?php echo e($productos->links()); ?>


</span>


</div>

<!-- Modal Agregar -->
<div class="modal fade" id="ModalAgregar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar Producto </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/admin/productos" method="post" enctype="multipart/form-data">

<?php echo csrf_field(); ?>

                <div class="modal-body">
 
                <?php if($message = Session::get('ErrorInsert')): ?> 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <!-- traigo los errores -->
                                 
        <li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>










                


                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="<?php echo e(old('nombre')); ?>" > 


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="admin" value="no"> 


                    </div>


                    
                    <div class="form-group">

<input type="hidden" class="form-control" name="slug" > 


                    </div>

                   

                    <div class="form-group">

<input type="hidden" class="form-control" name="author" value="<?php echo e(Auth::user()->name); ?>"  > 


                    </div>

                  

                    <div class="form-group">
                        
<input type="file" class="form-control" name="img" placeholder="Imagen"  >


                    </div>


                    <div class="form-group">
                        
<textarea type="text" class="form-control"  name="description" placeholder="Description" > </textarea>


                    </div>

                    <div class="form-group">
                        
                        <input type="number" class="form-control" name="stock" placeholder="Numero">
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                        <input type="text" class="form-control"  name="codigo" placeholder="Codigo">
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>

    </div>
  </div>
</div>


<!-- Modal Eliminar -->
<div class="modal fade" id="ModalEliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

                <div class="modal-body">
 
                <h5> Desea eliminar el Producto? </h5>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Eliminar</button>
                </div>
  

    </div>
  </div>
</div>


<!-- Modal Editar -->
<div class="modal fade" id="ModalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/admin/productos/edit" method="post"  enctype="multipart/form-data">

<?php echo csrf_field(); ?>

                <div class="modal-body">
 
                <?php if($message = Session::get('ErrorInsert')): ?> 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <!-- traigo los errores -->
                                 
        <li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>










                

<input type="hidden" name="id" id="idEdit">
                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="<?php echo e(old('nombre')); ?>" id="nombreEdit" > 


                    </div>


                    

                    <div class="form-group">
                        
<input type="text" class="form-control" name="codigo" placeholder="Codigo"  value="<?php echo e(old('codigo')); ?>" id="codigoEdit" >


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="slug" > 


                    </div>


                    <div class="form-group">

<input type="text" class="form-control" name="author" value="<?php echo e(Auth::user()->name); ?>" id="authorEdit" > 


                    </div>

                    
                    <div class="form-group">

<input type="hidden" class="form-control" name="admin" value="no" id="adminEdit" > 


                    </div>


                    <div class="form-group">

                    <input type="number" class="form-control" name="stock" placeholder="Numero" value="<?php echo e(old('stock')); ?>" id="stockEdit" >

                    </div>

                    <div class="form-group">
                        
                        <textarea type="text" class="form-control" name="description" placeholder="description" value="<?php echo e(old('description')); ?>" id="descriptionEdit"> </textarea>
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                                            <input type="file" class="form-control" name="img" placeholder="Imagen" id="imgEdit" value="<?php echo e(old('img')); ?>">
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>

    </div>
  </div>
</div>


<?php endif; ?>



<?php endif; ?>





<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>

<?php if($message = Session::get('ErrorInsert')): ?>

    

       

<script> 

$(document).ready(function(){
        

  $("#ModalAgregar").modal('show');   //este code es del lado del servidor si hay un error se ejecuta esto

    });







</script>


<?php endif; ?>


<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});

$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('nombre')); // el name le puse al atributo / data-name
$("#codigoEdit").val($(this).data('codigo'));
$("#authorEdit").val($(this).data('author'));
$("#adminEdit").val($(this).data('admin'));
$("#stockEdit").val($(this).data('stock'));
$("#slugEdit").val($(this).data('slug'));
$("#descriptionEdit").val($(this).data('description'));
$("#imgEdit").val($(this).data('img'));


});

</script>



<script src="<?php echo e(asset('../js/jquery-ui.js')); ?>">  </script>
        
      
        <script>
        
        
      
        $('#search').autocomplete({
        
        source: function(request, response){
$.ajax({

url: "<?php echo e(route('search.products')); ?>",
dataType: 'json',
data: {
term: request.term

},

success: function(data){

response(data)

} 


});


        }
        
        });
        
        
        
        
        
        
        
        
        
        </script>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/communitycreate.blade.php ENDPATH**/ ?>