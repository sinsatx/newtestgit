



<?php $__env->startSection('content'); ?>
<div class="container"> 
<div id="cokietodo"> 
<a href="<?php echo e(url('/')); ?>"> Back to Home Page </a>

<h1 class="cookieadvice">Cookie advice</h1>
<br> 
 <h2>WHAT ARE COOKIES? </h2>
 <br> 
 <p>  A cookie is a file that is downloaded to your computer when you access certain web pages. Cookies allow a website, among other things, to store and retrieve information about the browsing habits of a user or their computer and, depending on the information they contain and the way you use your computer, can be used to recognize the user. 
            </p> 
  <br>  <br> 
 
  <h2> WHAT TYPES OF COOKIES DOES THIS WEBSITE USE?  </h2>
 <br>
 <p>   This website uses the following types of cookies:
 
 Analysis Cookies: These are those that are well treated by us or by third parties, allow us to quantify the number of users and thus perform the measurement and statistical analysis of the use made by users of the service offered. To do this, your browsing on our website is analyzed in order to improve the supply of products or services we offer.
 
 Technical Cookies: These are those that allow the user to navigate through the restricted area and the use of its different functions, such as, for example, to carry out the purchase process of an article.
 
 Personalization Cookies: These are those that allow the user to access the service with some general characteristics predefined according to a series of criteria in the user's terminal such as the language or the type of browser through which it connects to the service.
 
 Advertising Cookies: These are those that, either treated by this website or by third parties, allow us to manage as effectively as possible the supply of advertising space on the website, adapting the content of the ad content to the content of the requested service or the use you make of our website. To do this we can analyze your browsing habits on the Internet and we can show you advertising related to your browsing profile.
 
 Behavioral advertising cookies: These are those that allow the management, in the most effective way possible, of the advertising spaces that, where appropriate, the editor has included on a website, application or platform from which the requested service is provided. This type of cookies store information on the behavior of visitors obtained through the continuous observation of their browsing habits, which allows the development of a specific profile to display advertisements based on the same.
</p> 
  <br> <br> 
 
  <h2> DISABLE COOKIES.  </h2>
 <br>
 <p>   You can allow, block or delete cookies installed on your computer by configuring the browser options installed on your computer.
 
 Most web browsers offer the possibility to allow, block or delete cookies installed on your computer.
 
 Below you can access the settings of the most common web browsers to accept, install or disable cookies:
 
 Configure cookies in Google Chrome
 
 Setting cookies in Microsoft Internet Explorer
 
 Setting cookies in Mozilla Firefox
 
 Setting cookies in Safari (Apple)

</p> 
 
  <br>  <br> 
 
  <h2> THIRD-PARTY COOKIES. </h2>
 <br>
<p> This website uses third party services to collect information for statistical and web usage purposes. DoubleClick cookies are used to improve the advertising included on the website. They are used to target advertising according to the content that is relevant to a user, thus improving the quality of experience in the use of the same.
 
 Specifically, we use Google Adsense and Google Analytics services for our statistics and advertising. Some cookies are essential to the operation of the site, for example the built-in search engine.
 
 Our site includes other functionalities provided by third parties. You can easily share content on social networks such as Facebook, Twitter or Google +, with the buttons we have included for this purpose. </p> 

   </p> 
  <br>  <br> 
 
  <h2> WARNING ABOUT DELETING COOKIES.</h2>
 <br> 
 <p> You can delete and block all cookies from this site, but part of the site will not work or the quality of the web page may be affected.
 
 If you have any questions about our cookie policy, you can contact this website through our Contact Us channels. </p>  
 </p>  


</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/cookies.blade.php ENDPATH**/ ?>