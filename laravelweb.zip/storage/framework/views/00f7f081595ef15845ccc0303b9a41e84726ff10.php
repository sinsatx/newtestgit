

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="<?php echo e(asset('css/programming.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylebody.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/singlepost.css')); ?>">
   
    <link rel="shortcut icon" href="../img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     


            
<div class="home_content">

<div class="text">









<div class="postsextras">


<h3 class="postlat"> Posts </h3>


<?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="todopost"> 

<div class="imgposts"> 
<a href="<?php echo e(route('posts.show',$posts)); ?> "> 

<img   src="/img/productos/<?php echo e($posts->img); ?>"/>  

</a>

</div>

<div class="postnombre"> 

<a class="linkpostnombre" href="<?php echo e(route('posts.show',$posts)); ?>" > <?php echo e($posts->nombre); ?>  </a> 

</div>

</div>




<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





</div>

<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 
<div class="singlePost">


            
            
            <div class="singlePostWrapper">


            

                <img class="singlePostImg" src="../img/productos/<?php echo e($producto->img); ?>" alt=""/>

                

<h1 class="singlePostTitle">
<?php echo e($producto->nombre); ?> 



<div class="singlePostEdit">
<!-- <i class="singlePostIcon fa fa-edit"></i>


<i class="singlePostIcon fa fa-remove"></i> -->


</div>

<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if(Auth::id() == $producto->userpost_id ): ?>

 <div class="btnedit2"> 

<a href="<?php echo e(route('postcom.show',$producto)); ?>">

<button class="btn btn-success btnEditar btnEdit"> 
<i class="fa fa-edit" > </i>     </button>

</a>

<a href="<?php echo e(route('postcom.show',$producto)); ?>">

<button class="btn btn-danger btnEliminar modal-btn1" id="btnelimi">  <i class="fa fa-trash" >   </i>  </button>

</a>

</div>

<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</h1>
<div class="singlePostInfo">


<span class="singlePostAuthor">Author: <b><?php echo e($producto->author); ?></b></span>
<span class="singlePostDate"> <?php echo e($producto->id); ?> </span>
    
</div>
<p class="singlePostDesc"><?php echo e($producto->description); ?></p>


<p> Tags: <?php echo e($producto->codigo); ?></p>

            </div>

        </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







<div class="form-grouptotal3" id="form-grouptotal3post">   


<h3>Creat Comment</h3>


<form   action="<?php echo e(route('logincoment-create')); ?>"  method="POST">
<?php echo csrf_field(); ?>

 <div class="form-group"> 

<input type="hidden"  name="id" id="name" >
</div> 




<?php if(Route::has('login')): ?>

<?php if(auth()->guard()->check()): ?>



<input type="hidden"  name="user_id" id="name" class="user1" value="<?php echo e(Auth::user()->id); ?>"  placeholder="User">




<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<input type="hidden"   name="id" id="name" class="user1" value="<?php echo e($producto->id); ?>"  placeholder="User">



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>

<?php endif; ?>

<?php endif; ?>


<div class="comment2">  

<div class="form-group" id="form-name1"> 

<textarea type="text" name="comment" id="name" class="tx1" placeholder="Login to Comment" rows="6" cols="30"></textarea>
</div>
</div>

<button type="submit" class="btn btn-success">Post</button>

</form>





</div>







<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>







<div class="form-grouptotal6" id="form-grouptotal6post"> 

<h1>Comments</h1>

</div>
       

 <!-- le agrege el $post -->

<?php $__currentLoopData = $comentariologins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentariologin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>





<div class="form-grouptotal4" id="form-grouptotalpost4">   





<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="<?php echo e($comentariologin->id); ?>">
</div>





<div class="form-group"> 
<label for="name" class="lab1">User: </label>
<?php echo e($comentariologin->usuario->name); ?>







<img src="<?php echo e(asset('users/'.$comentariologin->usuario->img)); ?>" id="imguser1" alt="">

</div>



<div class="form-group"> 
<label for="name"  class="lab2"><?php echo e($comentariologin->edit); ?> Comment: </label>
 <div class="comentar1">  <?php echo e($comentariologin->comment); ?></div> 
</div>



<!-- --------------------------- -->




<?php if(Auth::id() == $comentariologin->user_id ): ?>

<div> 

<a href="<?php echo e(route('comment.show',$comentariologin)); ?>">

<button class="btn btn-success btnEditar btnEdit" 

data-id="<?php echo e($comentariologin->id); ?>" 
data-ids="<?php echo e($comentariologin->ids); ?>" 
data-user_id="<?php echo e($comentariologin->user_id); ?>" 

data-comment="<?php echo e($comentariologin->comment); ?>"

data-toggle="modal" data-target="#ModalEditar" id="btnedit"  class="modal-bot1" > 
<i class="fa fa-edit" > </i>     </button>

</a>


<a href="<?php echo e(route('comment.show',$comentariologin)); ?>">
<button class="btn btn-danger btnEliminar modal-btn1" id="btnelimi" data-id="<?php echo e($comentariologin->ids); ?>" data-toggle="modal" data-target="#ModalEliminar">  <i class="fa fa-trash" >   </i>  </button>

</a>

</div>

<?php endif; ?>









</div>




<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>









<div class="postsextras2">


<h3 class="postlat2"> Posts </h3>


<?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="todopost2"> 

<div class="imgposts2"> 
<a href="<?php echo e(route('posts.show',$posts)); ?> "> 

<img   src="/img/productos/<?php echo e($posts->img); ?>"/>  

</a>

</div>

<div class="postnombre2"> 

<a class="linkpostnombre2" href="<?php echo e(route('posts.show',$posts)); ?>" > <?php echo e($posts->nombre); ?>  </a> 

</div>

</div>




<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





</div>


















</div>



</div>











<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>


var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});






$(".btnEditar").click(function(){

  $("#idEdit").val($(this).data('id'));

$("#idsEdit").val($(this).data('ids'));

$("#nombreEdit").val($(this).data('user_id')); // el name le puse al atributo / data-name



$("#descriptionEdit").val($(this).data('comment'));



});






</script>


<script>


var modalBtn = document.querySelector('.modal-btn1');
var modalBg = document.querySelector('.modal-bg1');
var modalClose = document.querySelector('.modal-close1');


modalBtn.addEventListener('click',function(){

modalBg.classList.add('bg-active');

});


modalClose.addEventListener('click',function(){

modalBg.classList.remove('bg-active');

});




</script>















       
        
        
        <script src="../js/cookies.js">  </script>
    
        
        
      

    

















  </html>
  


    

  








<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/post.blade.php ENDPATH**/ ?>