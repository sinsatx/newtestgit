


<div class="js-cookie-consent cookie-consent fixed bottom-0 inset-x-0 pb-2">

<div class="totalcookies" id="totalcookies">

<img src="img/cokie.png" class="cookieimg" alt="">


<div class="textcookie">  

<h3 class="titulocookies"> Cookies </h3>
<p class="parrafocookies">  
This website uses its own and third-party cookies to improve the service </p>


<a class="js-cookie-consent-agree cookie-consent__agree cursor-pointer flex items-center justify-center px-4 py-2 rounded-md text-sm font-medium text-yellow-800 bg-yellow-400 hover:bg-yellow-300">
    <button class="botoncookies" id="btn-aceptar-cookies"> I agree </button> </a>



<a class="enlacecookies" id="enlace1" href="<?php echo e(url('/cookies')); ?>"> Cookies Advice  </a>

</div>


</div>

</div><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/vendor/cookie-consent/dialogContents.blade.php ENDPATH**/ ?>