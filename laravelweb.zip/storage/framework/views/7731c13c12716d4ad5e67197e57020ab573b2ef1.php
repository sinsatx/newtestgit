<?php $__env->startSection('contenido'); ?>

<?php if(Auth::user()->nivel == 'admin'): ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"> Comments </h1>

                        




<a href="#" class=" d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar" onclick="comentarioadd()">
                            <i class="fas fa-user fa-sm text-white-50"></i> Add Comment
                        </a>

                        <a href="#" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#ModalAgregar" onclick="comentarioadd2()">
                            <i class=" fa-sm text-white-50" ></i> Hide Add Comment
                        </a>


                        



</div>




<?php $__empty_1 = true; $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p class="text-center">

No results found for: <strong> <?php echo e(request()->query('search')); ?> </strong>

</p>
<?php endif; ?>


<div id="addcomentario" class="form-grouptotal3">   


<h1>Creat Comment</h1>


<form   action="<?php echo e(route('coment-create')); ?>"  method="POST">
<?php echo csrf_field(); ?>

 <div class="form-group"> 

<input type="hidden"  name="id" id="name" >
</div> 


<div class="form-group" id="form-name1"> 
<label for="name">User</label>
<input type="text"  name="user" id="name" >
</div>

<label for="name">Comment</label>
<div class="form-group" id="form-name1"> 

<textarea type="text"  name="descripcion" id="name" cols="30" rows="7"></textarea>
</div>


<button type="submit" class="btn btn-success">Creat Comment</button>

</form>





</div>





<table class="table col-12 table-responsive">


  <thead>
  

      <tr> 
        <td> Id </td>
        <td> User </td>
        <td> Description </td>
        <td> &nbsp; </td> 
      <!-- Un espacio -->
           
      </tr>

      


  </thead>



  <tbody>


  <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr id="td2"> 







<td>   <?php echo e($comentario->id); ?> </td>

<td> <?php echo e($comentario->user); ?> </td>


<div > 
<td class="desc2"> <?php echo e($comentario->descripcion); ?> </td>


</div>


<td >   



  <button class="btn btn-success btnEditar" 
  data-id="<?php echo e($comentario->id); ?>" 
  data-user="<?php echo e($comentario->user); ?>" 

  data-descripcion="<?php echo e($comentario->descripcion); ?>"
  
  data-toggle="modal" data-target="#ModalEditar"> 
  <i class="fa fa-edit" > </i>     </button>    
      
  <button class="btn btn-danger btnEliminar" id="btnelimi" data-id="<?php echo e($comentario->id); ?>" data-toggle="modal" data-target="#ModalEliminar">  <i class="fa fa-trash" >   </i>  </button>



  <div class="botsepar1">  


  <form action="<?php echo e(route('coment-delete')); ?>" method="post" id="formEli_<?php echo e($comentario->id); ?>">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

<?php echo csrf_field(); ?>






<input type="hidden" name="id" value="<?php echo e($comentario->id); ?>">
<input type="hidden" name="_method" value="delete">

</form>

</div>

      </td> 


</tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>

</table>









<?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="form-grouptotal">   
















 
<!-- Modal Editar -->
<div class="modal fade" id="ModalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Comment Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     
<form action="<?php echo e(route('coment-update')); ?>"  method="POST" enctype="multipart/form-data">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>


                <div class="modal-body">
 
                <?php if($message = Session::get('ErrorInsert')): ?> 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <!-- traigo los errores -->
                                 
        <li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>









                

<input type="hidden" name="id" id="idEdit" value="<?php echo e($comentario->id); ?>">
                
                    <div class="form-group">

<input type="text" class="form-control" name="user" placeholder="Nombre"  value="<?php echo e($comentario->user); ?>" id="nombreEdit" > 


                    </div>

                  

                    <div class="form-group">
                        
                        <textarea type="text" placeholder="description" class="form-control" name="descripcion" value="<?php echo e($comentario->descripcion); ?>" id="descriptionEdit"></textarea>
                        
                        
                                            </div>

                                   

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
      </form>

    </div>
  </div>
</div>










</div>



<!-- Modal Eliminar -->
<div class="modal fade" id="ModalEliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Comment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

                <div class="modal-body">
 
                <h5> Do you want to delete the comment? </h5>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Delete</button>
                </div>
  

    </div>
  </div>
</div>









<!-- <a href="<?php echo e(url('/')); ?>"> <button class="btn btn-success" id="homeback"> Home  </button> </a> -->


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>



<span>  
<?php echo e($comentarios->links()); ?>


</span>

<?php endif; ?>


<?php if(Auth::user()->nivel == 'usuario'): ?>

<h1> User Page </h1>

<?php endif; ?>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});

$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('user')); // el name le puse al atributo / data-name

$("#descriptionEdit").val($(this).data('descripcion'));



});

</script>


<script>

function  comentarioadd(){

document.getElementById('addcomentario').style.display = 'block';
//poner todos los demas que aparecen en none para que se oculten

}

function  comentarioadd2(){

document.getElementById('addcomentario').style.display = 'none';
//poner todos los demas que aparecen en none para que se oculten

}








</script>




<script src="<?php echo e(asset('../js/jquery-ui.js')); ?>">  </script>
        
      
        <script>
        
        
      
        $('#search').autocomplete({
        
        source: function(request, response){
$.ajax({

url: "<?php echo e(route('search.commentwithoutlog')); ?>",
dataType: 'json',
data: {
term: request.term

},

success: function(data){

response(data)

} 


});


        }
        
        });
        
        
        
        
        
        
        
        
        
        </script>





<?php $__env->stopSection(); ?>



            
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/comments.blade.php ENDPATH**/ ?>