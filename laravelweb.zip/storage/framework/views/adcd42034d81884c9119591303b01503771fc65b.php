



<div class="alert cookiealert" role="alert">

<div class="totalcookies" id="totalcookies">




<!-- <img src="img/cokie.png" class="cookieimg" alt=""> -->


<div class="textcookie">  

<p class="titulocookies"> Cookies </p>
<p class="parrafocookies">  
This website uses its own and third-party cookies to improve the service </p>


<button type="button" class="botoncookies acceptcookies" id="btn-aceptar-cookies"> I agree </button>
<a class="enlacecookies" id="enlace1" href="<?php echo e(url('/cookies')); ?>"> Cookies Advice  </a>

</div>


</div>

</div>





<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/layouts/cookies.blade.php ENDPATH**/ ?>