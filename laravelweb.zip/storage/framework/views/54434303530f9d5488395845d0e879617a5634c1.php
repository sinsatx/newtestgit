

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="<?php echo e(asset('css/programming.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylebody.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/singlepost.css')); ?>">
   
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     


            
<div class="home_content">

<div class="text">



















<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>







<div class="form-grouptotal6" id="form-grouptotal6post"> 

<h1>Comment</h1>

</div>
       

 <!-- le agrege el $post -->

<?php $__currentLoopData = $comentariologins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentariologin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<?php if(Auth::id() == $comentariologin->user_id ): ?>


<div class="form-grouptotal4" id="form-grouptotalpost4">   





<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="<?php echo e($comentariologin->id); ?>">
</div>




<div class="form-group"> 
<label for="name" class="lab1">User: </label>
<?php echo e($comentariologin->usuario->name); ?>







<img src="<?php echo e(asset('users/'.$comentariologin->usuario->img)); ?>" id="imguser1" alt="">

</div>



<div class="form-group"> 
<label for="name"  class="lab2">Comment: </label>
 <div class="comentar1">  <?php echo e($comentariologin->comment); ?></div> 
</div>

<!-- --------------------------- -->


 




<!-- si saco el id="deletecomment" y id="editcomment"  -->

<!-- <div id="deletecomment">  -->








<!-- </div> -->


<!-- <div id="editcomment">   -->
  
     
<form action="<?php echo e(route('logincoment-update')); ?>"  method="POST" enctype="multipart/form-data" class="formeditid <?php echo e($comentariologin->ids); ?>" >

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>


                <div class="modal-body">
 
                <?php if($message = Session::get('ErrorInsert')): ?> 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <!-- traigo los errores -->
                                 
        <li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>







<div class="form-group">

<input type="hidden"  name="id" id="idEdit" value="<?php echo e($comentariologin->id); ?>"> 

</div>

<div class="form-group">

<input type="hidden"  name="ids" id="idsEdit" value="<?php echo e($comentariologin->ids); ?>">



</div>


<div class="form-group"> 

<input type="hidden"  name="edit" id="name" value="(edited)">
</div>

                
                    <div class="form-group">

<input type="hidden" class="form-control" name="user_id" placeholder="User_id"  value="<?php echo e($comentariologin->user_id); ?>" id="nombreEdit" > 


                    </div>

                  
                  

                    <div class="form-group">
                        
                        <textarea type="text" placeholder="Comment" class="form-control" name="comment" value="<?php echo e($comentariologin->comment); ?>" id="descriptionEdit"></textarea>
                        
                        
                                            </div>

                                            

                                   

                </div>
                <div class="modal-footer">
                 
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
      </form>

   

      <!-- </div> -->


     
<!-- ---------------------------------- -->




<form action="<?php echo e(route('logincoment-delete2')); ?>" method="post"  class="deletcomid <?php echo e($comentariologin->ids); ?>">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

<?php echo csrf_field(); ?>


<button class="btn btn-danger btnEliminar" id="btnelimi" data-id="<?php echo e($comentariologin->ids); ?>" data-toggle="modal" data-target="#ModalEliminar"> Click Here To Delete the Comment <i class="fa fa-trash" >   </i>  </button>



<input type="hidden" name="id" value="<?php echo e($comentariologin->ids); ?>">
<input type="hidden" name="_method" value="delete">

</form>


</div>





<?php else: ?> 

<h2> You Cannot Edit or Delete this Comment</h2>


<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>










</div>




</div>












<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});


$(".btnEditar").click(function(){

  $("#idEdit").val($(this).data('id'));

$("#idsEdit").val($(this).data('ids'));

$("#nombreEdit").val($(this).data('user_id')); // el name le puse al atributo / data-name



$("#descriptionEdit").val($(this).data('comment'));



});



// function  editcomment(){

// document.getElementsByClassName('editcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('deletcom').style.display = 'none';
// }

// function  deletecomment(){

// document.getElementsByClassName('deletcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('editcom').style.display = 'none';
// }


</script>


















       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    

        
  </html>
  


    






















<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/postcomment.blade.php ENDPATH**/ ?>