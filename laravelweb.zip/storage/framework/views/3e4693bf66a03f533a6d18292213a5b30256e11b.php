   
  

    

    <?php $__env->startSection('content2'); ?>

     


            
<div class="home_content">

<div class="text">
    

<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



<table>

<li>Nombre: <?php echo e($usuario->name); ?> </li>



</table>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>

</div>



            <?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/settings.blade.php ENDPATH**/ ?>