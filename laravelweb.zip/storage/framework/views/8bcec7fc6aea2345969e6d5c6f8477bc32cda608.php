

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="<?php echo e(asset('css/programming.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylebody.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/singlepost.css')); ?>">
   
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     


            
<div class="home_content">

<div class="text">











<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<?php if(Auth::id() == $producto->userpost_id ): ?>

<h1>You can Edit</h1>


<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


<?php if($message = Session::get('alertd')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


<!-- veer esto del form deee eeditar -->

<form action="<?php echo e(route('postadm.edit')); ?>" method="post"  enctype="multipart/form-data">
<?php echo method_field('PUT'); ?>
<?php echo csrf_field(); ?>

<div class="modal-body">
 
 <?php if($message = Session::get('ErrorInsert')): ?> 
<!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- traigo los errores -->
                  
<li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>











                

<input type="hidden" name="id" id="idEdit" value="<?php echo e($producto->id); ?>">
                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="<?php echo e($producto->nombre); ?>" id="nombreEdit" > 


                    </div>


                    

                    <div class="form-group">
                        
<input type="text" class="form-control" name="codigo" placeholder="Codigo"  value="<?php echo e($producto->codigo); ?>" id="codigoEdit" >


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="slug" > 


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="author" value="<?php echo e($producto->author); ?>" id="authorEdit" > 


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="userpost_id" value="<?php echo e(Auth::user()->id); ?>" id="userpostidEdit" > 


                    </div>

                    
                    <div class="form-group">

<input type="hidden" class="form-control" name="admin" value="<?php echo e($producto->admin); ?>" id="adminEdit" > 


                    </div>



                    <div class="form-group">
                        
                        <textarea type="text" class="form-control" name="description" placeholder="description" value="<?php echo e($producto->description); ?>" id="descriptionEdit"><?php echo e($producto->description); ?></textarea>
                        
                        
                                            </div>

                                            <div class="form-group">
                        
                                            <input type="file" class="form-control" name="img" placeholder="Imagen" id="imgEdit" value="">  
                        
                        
                                            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>






<form action="<?php echo e(route('post-delete3')); ?>" method="post"  class="deletcomid <?php echo e($producto->id); ?>">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

<?php echo csrf_field(); ?>


<button class="btn btn-danger btnEliminar" id="btnelimi" data-id="<?php echo e($producto->id); ?>" data-toggle="modal" data-target="#ModalEliminar"> Click Here To Delete the Post <i class="fa fa-trash" >   </i>  </button>



<input type="hidden" name="id" value="<?php echo e($producto->id); ?>">
<input type="hidden" name="_method" value="delete">

</form>


</div>

<?php if($message = Session::get('ErrorInsert')): ?>

<?php endif; ?>








<?php else: ?> 

<h2> You Cannot Edit or Delete this Comment</h2>


<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






</div>




</div>












<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});


$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('nombre')); // el name le puse al atributo / data-name
$("#codigoEdit").val($(this).data('codigo'));
$("#authorEdit").val($(this).data('author'));
$("#adminEdit").val($(this).data('admin'));
$("#userpostidEdit").val($(this).data('userpost_id'));

$("#slugEdit").val($(this).data('slug'));
$("#descriptionEdit").val($(this).data('description'));
$("#imgEdit").val($(this).data('img'));


});





// function  editcomment(){

// document.getElementsByClassName('editcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('deletcom').style.display = 'none';
// }

// function  deletecomment(){

// document.getElementsByClassName('deletcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('editcom').style.display = 'none';
// }


</script>


















       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    

        
  </html>
  


    






















<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/postcom.blade.php ENDPATH**/ ?>