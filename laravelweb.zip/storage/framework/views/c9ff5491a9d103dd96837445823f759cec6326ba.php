
    

<div class="sidebar">

<div class="logo_content">


<div class="logo">

<i class="fa fa-globe"> </i>

<div class="logo_name">SinsatoXP</div>

</div>

<i class="fa fa-bars" id="btn"> </i>


</div>


<ul class="nav_list">

<form action="" method="GET">
<li>


<input type="text" placeholder="Search..." name="search" id="search">

<span class="tooltip">Search </span>
<i class="fa fa-search"> </i> 


</li>
</form>






<li>
<a href="<?php echo e(url('/')); ?>">
<i class="fa fa-home"> </i>
<span class="links_name">Home </span>
</a>
<span class="tooltip">Home </span>

</li>

<li>
<a href="<?php echo e(url('/about')); ?>">
<i class="fa fa-info-circle"> </i>
<span class="links_name">About </span>
</a>
<span class="tooltip">About </span>

</li>

<li>
<a href="<?php echo e(url('/programming')); ?>">
<i class="fa fa-cloud"> </i>
<span class="links_name">Programming </span>
</a>
<span class="tooltip">Programming </span>

</li>

<li>
<a href="<?php echo e(url('/videos')); ?>">
<i class="fa fa-youtube-play"> </i>
<span class="links_name">Videos </span>
</a>
<span class="tooltip">Videos </span>

</li>

<li>
<a href="<?php echo e(url('/community')); ?>">
<i class="fa fa-group"> </i>
<span class="links_name">Community </span>
</a>
<span class="tooltip">Community </span>

</li>



<li>
<a href="<?php echo e(url('/contact')); ?>">
<i class="fa fa-comment-o"> </i>
<span class="links_name">Contact </span>
</a>
<span class="tooltip">Contact </span>

</li>

<?php if(Route::has('login')): ?>

<?php if(auth()->guard()->check()): ?>

<li>
<a href="<?php echo e(url('/setting')); ?>">
<i class="fa fa-gear"> </i>
<span class="links_name">Settings </span>
</a>
<span class="tooltip">Settings </span>

</li>

<?php if(Auth::user()->nivel == 'admin'): ?>

<li>
<a href="<?php echo e(url('/admin')); ?>">
<i class="fa fa-newspaper-o"> </i>
<span class="links_name">DashBoard</span>
</a>
<span class="tooltip">DashBoard </span>

</li>

<?php endif; ?>


<?php else: ?>

<li>
 <a href="<?php echo e(route('login')); ?>"> 
<i class="fa fa-user"> </i>
<span class="links_name">Login </span>
</a>
<span class="tooltip">Login </span>

</li>


<?php if(Route::has('register')): ?>
<li>
<a href="<?php echo e(route('register')); ?>">
<i class="fa fa-registered"> </i>
<span class="links_name">Register </span>
</a>
<span class="tooltip">Register </span>

</li>
<?php endif; ?>




<?php endif; ?>



<?php endif; ?>








</ul>

<?php if(Route::has('login')): ?>

<?php if(auth()->guard()->check()): ?>

<div class="profile_content">

<div class="profile">




<div class="profile_details">


<img src="<?php echo e(asset('/users/'.Auth::user()->img)); ?>" alt="">
<div class="name_job">

<div class="name"><?php echo e(Auth::user()->name); ?></div>

<div class="job">User Account</div>

</div>


</div>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <button>          <i  class="fa fa-power-off" id="log_out"></i> </button>  
                                        
                                    </form>


                                  


</div>



</div>







                            

                <?php else: ?>



<div class="profile_content">

<div class="profile">




<div class="profile_details">


<img src="img/sett1.jpg" alt="">
<div class="name_job">

<div class="name">Sinsato Work </div>

<div class="job">Web development</div>

</div>


</div>

<!-- <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <button>          <i  class="fa fa-power-off" id="log_out"></i> </button>  
                                        
                                    </form> -->


                                  


</div>



</div>





<?php endif; ?>



<?php endif; ?>








</div>


       
            <?php echo $__env->yieldContent('content2'); ?>
        

<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/layouts/topsidebar2.blade.php ENDPATH**/ ?>