

<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link rel="stylesheet" href="<?php echo e(asset('css/Topbar2.css')); ?>">

</head>
<body>
    

 
<div class="SidebarTop">
          


          <div class="todobar2"> 
          
          
                      <nav class="nav2">
                                 
                      <ul class="list">

                      <a href="<?php echo e(url('/about')); ?>">           <li class="items">  Home  </li> 
              
                      <a href="<?php echo e(url('/about')); ?>">           <li class="items">  About  </li> 
             
                     
             
                      <a href="<?php echo e(url('/programming')); ?>">           <li class="items">  Programming  </li> 

                      <a href="<?php echo e(url('/contact')); ?>">           <li class="items">  Contact   </li> 

    <?php if(Route::has('login')): ?>
                
                    <?php if(auth()->guard()->check()): ?>
                    <ul class="rightlist">
                           <a href="<?php echo e(url('/home')); ?>">      <li class="items">  Home </li>  </a> 
                    <?php else: ?>
                               <a href="<?php echo e(route('login')); ?>">  <li class="items right">    Log in  </li>   </a>  
              

                        <?php if(Route::has('register')): ?>
                                     <a href="<?php echo e(route('register')); ?>">    <li class="items right">  Register   </li>  </a>  
                        <?php endif; ?>
                    <?php endif; ?>
                
            <?php endif; ?>
            </ul>
                          </ul>
          
          
                          <button class="btn" onClick={toggleNav}> Menu  </button>
                  </nav>
          
          
                  </div>

            
        </div>
       
            <?php echo $__env->yieldContent('content2'); ?>
        


</body>
</html> -->
<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/layouts/sidebartop.blade.php ENDPATH**/ ?>