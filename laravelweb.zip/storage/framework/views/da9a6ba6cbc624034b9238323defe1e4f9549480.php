

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>

    <link rel="shortcut icon" href="img/iconsinsa4.png">
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>


<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
  <body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  


     


            
<div class="home_content">

<div class="text">



<!-- <div class="fondoef">   -->

<!-- <div class="wrapper">
<div class="static-txt">I´ am a</div>
<ul class="dynamic-txts">
<li> <span> Youtuber </span> </li>
<li> <span> Editor </span> </li>
<li> <span> Freelancer </span> </li>
<li> <span> Full Stack Developer </span> </li>

</ul>

</div>

</div> -->

<div class="container cont1" id="contact1">
	<div class="row">
		<div class="col-md-8 mx-auto">
			<div class="contact-form send2">
				<h1 class="send1" id="send2">Send me a Message</h1>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success" id="message1">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('send.email')); ?>" method="post">
                <?php echo csrf_field(); ?>


					<div class="row">
						
							<div class="form-group">
								<label for="inputName">Email</label>
								<input type="text" name="name" class="form-control" placeholder="Email">
                                
							</div>
						
							<div class="form-group" >
								<!-- <label for="inputEmail">Email</label> -->
								<input type="hidden" name="email"  class="form-control" value="sinsatoxp1@gmail.com" placeholder="Email">
                                
							</div>
						
					</div>            
					<div class="form-group">
						<label for="inputSubject">Subject</label>
                        <input type="text" name="subject" class="form-control" placeholder="Subject">
                      
					</div>
					<div class="form-group">
						<label for="inputMessage">Message</label>
                        <textarea name="content" rows="5" class="form-control" placeholder="Message"></textarea>
                      
					</div>
					<div class="text-center">
						<button type="submit" class="btn btn-primary" id="botonemail1"> <i class="fa fa-paper-plane"></i> Send</button>
					</div>            
				</form>
			</div>
      
		</div>

   

	</div>
  

</div>



<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="row2"> 
                                <span class="text-danger2"> <?php echo e($message); ?> </span> <br> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger2"> <?php echo e($message); ?> </span> <br> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger2"> <?php echo e($message); ?> </span> <br> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger2"> <?php echo e($message); ?> </span> <br> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



<div class="contx"> 

<h3 class=formul1> || </p> <br>
  


<h3 class=formul3> You can Hire me <br> (Podes contratarme en) :</p>


<a href="https://www.fiverr.com/sinsatox">    <img src="img/fiv1.png" id="gmail1" alt="gmail" width="400px" alt=""/> </a>



</div>



</div>



</div>

         
<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
        
        
        
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
      
        
        
        
        
      

    
        <script src="js/cookies.js">  </script>
    










</html>




  </body>
  </html>
  


    

  



<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/contact.blade.php ENDPATH**/ ?>