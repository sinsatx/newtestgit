

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="<?php echo e(asset('css/programming.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylebody.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/singlepost.css')); ?>">
   
    <link rel="shortcut icon" href="img/iconsinsa4.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     


            
<div class="home_content">

<div class="text">



<h1>Create a Post</h1>


<form action="<?php echo e(route('creatpost')); ?>" method="post" enctype="multipart/form-data">

<?php echo csrf_field(); ?>

                <div class="modal-body">
 
                <?php if($message = Session::get('ErrorInsert')): ?> 
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Registro: </h5>

<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <!-- traigo los errores -->
                                 
        <li> <?php echo e($error); ?> </li>   


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

</div>

<?php endif; ?>










                


                
                    <div class="form-group">

<input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="<?php echo e(old('nombre')); ?>" > 


                    </div>


                    <div class="form-group">

<input type="hidden" class="form-control" name="admin" value="no"> 


                    </div>


                    
                    <div class="form-group">

<input type="hidden" class="form-control" name="slug" > 


                    </div>

                   

                    <div class="form-group">

<input type="hidden" class="form-control" name="author" value="<?php echo e(Auth::user()->name); ?>"> 


                    </div>

                


                    <div class="form-group">

<input type="hidden" class="form-control" name="userpost_id" value="<?php echo e(Auth::user()->id); ?>"> 


                    </div>

                  

             


                    <div class="form-group">
                        
<textarea type="text" class="form-control"  name="description" placeholder="Description"></textarea>


                    </div>

                 

                                            <div class="form-group">
                        
                        <input type="text" class="form-control"  name="codigo" placeholder="Tags">
                        
                        
                                            </div>

                               

                                            <div class="form-group">
                        
                        <input type="file" class="form-control" name="img" placeholder="Imagen"  >
                        
                        
                                            </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>




      <?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


<?php if($message = Session::get('alertd')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>






</div>




</div>












<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
        
       

        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        

        <script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});


$(".btnEditar").click(function(){

$("#idEdit").val($(this).data('id'));
$("#nombreEdit").val($(this).data('nombre')); // el name le puse al atributo / data-name
$("#codigoEdit").val($(this).data('codigo'));
$("#authorEdit").val($(this).data('author'));
$("#adminEdit").val($(this).data('admin'));
$("#userpostidEdit").val($(this).data('userpost_id'));
$("#stockEdit").val($(this).data('stock'));
$("#slugEdit").val($(this).data('slug'));
$("#descriptionEdit").val($(this).data('description'));
$("#imgEdit").val($(this).data('img'));


});





// function  editcomment(){

// document.getElementsByClassName('editcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('deletcom').style.display = 'none';
// }

// function  deletecomment(){

// document.getElementsByClassName('deletcom').style.display = 'block';
// //poner todos los demas que aparecen en none para que se oculten
// document.getElementsByClassName('editcom').style.display = 'none';
// }


</script>


















       
        
        
        <script src="js/cookies.js">  </script>
    
        
        
      

    

        
  </html>
  


    






















<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/createpost.blade.php ENDPATH**/ ?>