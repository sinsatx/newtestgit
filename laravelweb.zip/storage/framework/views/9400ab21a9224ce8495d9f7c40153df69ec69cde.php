<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('css/setting.css')); ?>">
  <title>Document</title>
</head>
<body>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<a href="<?php echo e(url('/setting')); ?>"> <button class="btn btn-success" id="homeback2"> Setting Menu  </button> </a>

<div class="form-grouptotal2"> 


<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="<?php echo e($usuarios->id); ?>">
</div>





<form action="<?php echo e(url('/settingdelete', ['id'=>$usuarios->id])); ?>" method="post" id="formEli_<?php echo e($usuarios->id); ?>">
                                                            <!-- como se repite el formulario tieene que tener diferentes id -->

<?php echo csrf_field(); ?>
<div class="form-group" id="deletgroup"> 

<div> Click to Delete Your Account </div>

<button class="btn btn-round btnEliminar" id="btnelimi" data-id="<?php echo e($usuarios->id); ?>" data-toggle="modal" data-target="#ModalEliminar"> Delete Account  </button>


</div>



<input type="hidden" name="id" value="<?php echo e($usuarios->id); ?>">
<input type="hidden" name="_method" value="delete">

</form> 







                        

                        
      









<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


</div>



















</body>



<?php $__env->startSection('scripts'); ?>





<script>

  var idEliminar=0;

$(".btnEliminar").click(function(){

idEliminar = $(this).data('id');


});

$(".btnModalEliminar").click(function(){

$("#formEli_"+idEliminar).submit();


});







</script>

<?php $__env->stopSection(); ?>

</html>

            <?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/settingdelete.blade.php ENDPATH**/ ?>