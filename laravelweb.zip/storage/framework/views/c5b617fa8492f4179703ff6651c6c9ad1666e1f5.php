<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<style>
*{
margin: 0;
padding: 0;

}


.titulo{
text-align: center;
font:2rem;
color:blue;
margin-bottom: 7%;

}

.thead1{

width: 100%;

}

.trprod{

margin-top: 7%;

}


.theadpart{
margin-bottom: 20%;

color:red
}

</style>
 
</head>
<body>
    <div>

<h1 class="titulo" >Products</h1>

<table class="thead1">
        <thead  > 
                <tr class="theadpart"> 
                        
        <td> Id </td>
        <td> Nombre </td>
        <td> Codigo </td>
        <td> Description </td>
        
        <td> &nbsp; </td> 



                </tr>
        </thead>
<tbody> 
<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<tr class="trprod">

        


        <td> <?php echo e($producto->id); ?> </td>
        <td> <?php echo e($producto->nombre); ?> </td>
        <td> <?php echo e($producto->codigo); ?> </td>
        <td> <?php echo e($producto->description); ?> </td>

        <td> &nbsp; </td>
       



</tr>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>


</table>

  
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/pdf/reporteproductos.blade.php ENDPATH**/ ?>