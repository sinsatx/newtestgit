<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('css/setting.css')); ?>">
  <title>Document</title>
</head>
<body>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<a href="<?php echo e(url('/setting')); ?>"> <button class="btn btn-success" id="homeback2"> Setting Menu  </button> </a>

<div class="form-grouptotal2"> 


<form action="<?php echo e(route('users.editpassword')); ?>"  method="POST" enctype="multipart/form-data">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>


<div class="form-group"> 

<input type="hidden"  name="id" id="name" value="<?php echo e($usuarios->id); ?>">
</div>


 <div class="form-group"> 
<label for="name" id="passw1">Password</label>
<input type="password"  name="pass1" id="name" value="">


</div> 


<div class="form-group"> 
<label for="name">Repeat Password</label>
<input type="password"  name="pass2" id="name" value="">


</div> 



                        

                        
      


<button type="submit" class="btn btn-success" id="updat1">Update Password</button>




</form>  




<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Mensaje: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>


</div>


<!-- <a href="<?php echo e(url('/')); ?>"> <button class="btn btn-success" id="homeback"> Home  </button> </a> -->
















</body>
</html>

            <?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/settingpassword.blade.php ENDPATH**/ ?>