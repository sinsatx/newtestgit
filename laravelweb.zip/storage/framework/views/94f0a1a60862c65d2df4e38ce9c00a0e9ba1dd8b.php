

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaravelWebSx</title>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H6V1NCDDP9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H6V1NCDDP9');
</script>

<link rel="stylesheet" href="<?php echo e(asset('css/programming.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('css/topsidebar2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylebody.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cookies.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">

    <link rel="shortcut icon" href="img/iconsinsa4.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body>


  <?php echo $__env->make('layouts.topsidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     
  

            
<div class="home_content">

<div class="text">



<?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p class="text-center">

No Products found: <strong> <?php echo e(request()->query('search')); ?> </strong>

</p>
<?php endif; ?>


<a href="community/posts" class="comcreate"> 
<button class="btn btn-danger btncreat">  Create Post <i class="fa fa-pencil" > </i>   </button></a> 


<div class="postcomplet"> 

<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<div class="post">

<!-- <h2 class="textdat"> Programming - Articulos - DateBase Tabla (Datos de la Tabla) </h2>
     -->



     <img class="postImg" src="img/productos/<?php echo e($producto->img); ?>  "/>  

     <div class="postInfo">
<div class="postCats">
<span class="postCat">Community</span>
<span class="postCat">Posts</span>

</div>

<a href="<?php echo e(route('posts.show',$producto)); ?> "> <span class="postTitle">  <?php echo e($producto->nombre); ?> </span> </a>
<hr />

<span class="postDate"> <?php echo e($producto->stock); ?> </span>
</div>


<p class="postDesc"> <?php echo e($producto->description); ?> </p>

</div>



<!-- <table> 

<div class="elementocompleto"> 

<li class="elementsproducts list-group-item">Nombre: <?php echo e($producto->nombre); ?> </li>

<li class="elementsproducts list-group-item">Numero:  </li>

<li class="elementsproducts list-group-item">Codigo: <?php echo e($producto->codigo); ?> </li>

<li class="elementsproducts list-group-item">Descripcion: <?php echo e($producto->description); ?> </li>

<li class="elementsproducts list-group-item"> <</li>




</div>


</table> -->

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






</div>







<?php if($message = Session::get('Listo')): ?>  
  <!-- el if se usa con arroba -->

<div class="col-12 alert alert-success alert-dismissable fade show" role="alert">

<h5> Message: </h5>

<span>  <?php echo e($message); ?>     </span>

</div>

<?php endif; ?>







</div>


</div>






<?php echo $__env->make('layouts.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
        
       
        
        
        
        
        
        <script>
        
        
        let btn = document.querySelector("#btn");
        let sidebar = document.querySelector(".sidebar");
        let searchBtn = document.querySelector(".fa-search");
        
        
        btn.onclick = function() {
        sidebar.classList.toggle("active");
        
        }
        
        
        searchBtn.onclick = function(){
        
        sidebar.classList.toggle("active");
        
        
        }
        
        
        
        
        
        </script>
        
       
        
        
        <script src="js/cookies.js">  </script>

        <script src="../js/jquery-3.6.0.min.js">  </script>
    
        <script src="../js/jquery-ui.js">  </script>
        
      




           
        <script>
        
        
      
        $('#search').autocomplete({
        
        source: function(request, response){
$.ajax({

url: "<?php echo e(route('search.product')); ?>",
dataType: 'json',
data: {
term: request.term

},

success: function(data){

response(data)

} 


});


        }
        
        });
        
        
        
        
        
        
        
        
        
        </script>


    
















  </body>
  </html>
  


    

  








<?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/community.blade.php ENDPATH**/ ?>