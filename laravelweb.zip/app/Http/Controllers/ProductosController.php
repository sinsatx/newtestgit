<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Auth;


use App\Models\Producto;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManagerStatic;
use Barryvdh\DomPDF\Facade as PDF;


class ProductosController extends Controller
{

    
    
    public function index()
    {
        $productos = Producto::all();

        $search = request()->query('search') ;

        if($search){
        
        
            $posts = Producto::where('nombre', 'LIKE', "%{$search}%")->Paginate(2);
        
        
        } else{
        
        $posts = Producto::Paginate(3);
        
        }

 
        return view('productos') -> with('productos',$posts);


    }

    public function imprimir()
    {
        $productos = DB::table('productos') // la tabla que voy a usar
        ->select('productos.*') // .* significa para todos los campos
                      //ascendente
        ->OrderBy('stock','ASC')
        ->take(10)

        ->get();

$fecha= date('Y-m-d');
$data = compact('productos','fecha');

        $pdf = PDF::loadView('pdf.reporteproductos', $data); 

        // para que se descarge directamente
        return $pdf->download('reporte_'.time().'.pdf');

        // para que salga una ventana
        return $pdf->stream();
    }



    

    public function All(Request $request)
    {
    

        $productos = DB::table('productos') // la tabla que voy a usar
        ->select('productos.*') // .* significa para todos los campos
                      //ascendente
        ->OrderBy('stock','ASC')
        ->take(10)

        ->get();

                  //lo traemos a formato json para que javascript lo pueda leer
        return response(json_encode($productos),200)->header('Content-type','text/plain');

    }
    

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[

'nombre' => 'required|min:3|max:20',
            // tipo imagen // permitidos           //max peso
'img' => 'required|image|mimes:jpg,jpeg,png,gif,svg|max:2048',

'description' => 'required', 
          //requerido / minimo 3 charact //requerido con el password2 / y que sea igual al password2
          'codigo' => 'required', 
          'admin' => 'required',
          'author' => 'required',
          'userpost_id' => 'required',
      

        ]);

if ($validator ->fails()){


// dd('Rellena los campos');  // es lo mismo que decir echo

                return back()

                ->withInput()
                ->with('ErrorInsert','rellene todos los campos')
            
                ->withErrors($validator);


} else {

    $imagen = $request -> file('img');
               // para que diga por ejemplo : 02_12_2020.jpg
    $nombre = time().'.'.$imagen->getClientOriginalExtension();

    $destino = public_path('img/productos');

    // FIJARSE AL PASAR en el hosting uso este:     $destino = base_path().'/../public_html/img/productos/';


// Esto es para el hosting |    $destino = base_path().'/../laravelxs/public/img/productos';

    $request->img->move($destino, $nombre);
 

    $red = Image::make($destino.'/'.$nombre);
     $red->resize(1280, null, function ($constraint) {
         $constraint->aspectRatio();
 });

 $red->save($destino.'/'.$nombre);
// $marca_agua= Image::make($destino.'/'.$nombre);
// $logo= Image::make(public_path('img/logo.png'));
// $logo->fit(100);

// $marca_agua->insert($logo, 'bottom-right',7,7);

// $marca_agua->save();

// $request->merge([

// 'slug'=>Str::slug($request->nombre),

// ]);

$producto = Producto::create([

'nombre'=>$request->nombre,
'img'=>$nombre,

'admin'=>$request->admin,
'codigo'=>$request->codigo,
'author'=>$request->author,
'userpost_id'=>$request->userpost_id,

'description'=>$request->description,
'slug'=> Str::slug($request->nombre),

]);

 return back()->with('Listo','Se ha insertado Correctamente');

}



        // dd($request); esto interrumpe la coneccion eentonces lo saco

 // si solo quiero el atributo nombre / dd($request->$nombre);
    }








    public function edit(Request $request)
    {
        
$producto = Producto::findOrFail($request->id);

$validator = Validator::make($request->all(),[

    'nombre' => 'required',
    'codigo' => 'required',
    'description' => 'required',
    
  
         
    
            ]);

            // if($request->hasFile('img')){

            //     $destination = 'users/'.$usuario->img;
            //     if(File::exists($destination)){
                
            //     File::delete($destination);
                
            //     }
                
              
                
                
                
            //     }


            if ($validator ->fails()){
        
        
                // dd('Rellena los campos');  // es lo mismo que decir echo
                
                                return back()
                
                                ->withInput()
                                ->with('Alertd','Fill in all fields correctly')
                            
                                ->withErrors($validator);
                
                
                } else {
        
                                        //    $file = $request->file('img');
                                        //    $extension = $file->getClientOriginalExtension();
                                        //    $filename = time().'.'.$extension;
                                        //    $file -> move('../img/productos/',$filename);
                                        //    $producto->img = $filename;

                                   //asi se llama en el input el name




                                   if($request->hasFile('img')){

                                    $file =  $request->file('img');
                                    $extension = $file->getClientOriginalExtension();
                                    $filename = time(). '.' . $extension;
                                    $file-> move('./img/productos/',$filename);
                                    $producto->img = $filename;
                                    

                                    }

                                    $producto->author = $request->author;  
                                    $producto->admin = $request->admin;  
                               
                                   $producto->nombre = $request->nombre;   
                                   $producto->codigo = $request->codigo; 
                                   $producto->description = $request->description;
                                   $producto->slug = Str::slug($request->nombre); 
                                 
                                 

//para la contraseña

$validator2 = Validator::make($request->all(),[


    'description' => 'required', 
              //requerido / minimo 3 charact //requerido con el password2 / y que sea igual al password2
                 
    
            ]);

            //si No Falla se va actualizar el password(osea sino se pone bien se actualiza lo de arriba y esto lo ignora)
            if(!$validator2->fails()){


            }

            
            //para la contraseña


            $producto->save();   
            return back()->with('Listo','It has been posted correctly');


} //llave else validar

                      }




                    

  
    





  
    










    

    public function destroy($id)
    {
        $producto = Producto::find($id);
        $producto->delete();
        return back()->with('Listo','El Registro se ha Eliminado Correctamente');







        
    }
    



























    

}
