<?php

namespace App\Http\Controllers;

use App\Models\Comentariologin;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Auth;


use App\Models\Producto;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManagerStatic;
use Barryvdh\DomPDF\Facade as PDF;


class CommunityController extends Controller
{

    
    
    public function index(Producto $id)
    {
        
        

 
        $usuarios = User::all();

   $productos = Producto::OrderBy('id','DESC')->where('id','!=',$id->id)->take(1)->get();
   

 

     return view('createpost',compact('usuarios','productos'));


    }

   
    public function imprimir()
    {
        $productos = DB::table('productos') // la tabla que voy a usar
        ->select('productos.*') // .* significa para todos los campos
                      //ascendente
        ->OrderBy('stock','ASC')
        ->take(10)

        ->get();

$fecha= date('Y-m-d');
$data = compact('productos','fecha');

        $pdf = PDF::loadView('pdf.reporteproductos', $data); 

        // para que se descarge directamente
        return $pdf->download('reporte_'.time().'.pdf');

        // para que salga una ventana
        return $pdf->stream();
    }



    

    public function All(Request $request)
    {
    

        $productos = DB::table('productos') // la tabla que voy a usar
        ->select('productos.*') // .* significa para todos los campos
                      //ascendente
        ->OrderBy('stock','ASC')
        ->take(10)

        ->get();

                  //lo traemos a formato json para que javascript lo pueda leer
        return response(json_encode($productos),200)->header('Content-type','text/plain');

    }
    

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[

            'nombre' => 'required|min:3|max:20',
            // tipo imagen // permitidos           //max peso
'img' => 'required|image|mimes:jpg,jpeg,png,gif,svg|max:2048',

'description' => 'required', 
          //requerido / minimo 3 charact //requerido con el password2 / y que sea igual al password2
          'codigo' => 'required', 
          'admin' => 'required',
          'author' => 'required',
          'userpost_id' => 'required',
      

        ]);

if ($validator ->fails()){


// dd('Rellena los campos');  // es lo mismo que decir echo

                return back()

                ->withInput()
                ->with('ErrorInsert','rellene todos los campos')
            
                ->withErrors($validator);


} else {

    $imagen = $request -> file('img');
               // para que diga por ejemplo : 02_12_2020.jpg
    $nombre = time().'.'.$imagen->getClientOriginalExtension();

    $destino = public_path('img/productos');

    // FIJARSE AL PASAR en el hosting uso este:     $destino = base_path().'/../public_html/img/productos/';


// Esto es para el hosting |    $destino = base_path().'/../laravelxs/public/img/productos';

    $request->img->move($destino, $nombre);
 

    $red = Image::make($destino.'/'.$nombre);
     $red->resize(1280, null, function ($constraint) {
         $constraint->aspectRatio();
 });

 $red->save($destino.'/'.$nombre);
// $marca_agua= Image::make($destino.'/'.$nombre);
// $logo= Image::make(public_path('img/logo.png'));
// $logo->fit(100);

// $marca_agua->insert($logo, 'bottom-right',7,7);

// $marca_agua->save();

// $request->merge([

// 'slug'=>Str::slug($request->nombre),

// ]);

$producto = Producto::create([

    'nombre'=>$request->nombre,
    'img'=>$nombre,
    
    'admin'=>$request->admin,
    'codigo'=>$request->codigo,
    'author'=>$request->author,
    'userpost_id'=>$request->userpost_id,
    
    'description'=>$request->description,
    'slug'=> Str::slug($request->nombre),
    

]);


return back()->with('Listo','Successfully posted!');


}



        // dd($request); esto interrumpe la coneccion eentonces lo saco

 // si solo quiero el atributo nombre / dd($request->$nombre);
    }








    public function update(Request $request, Producto $id)
    {
   

          
  
$producto = Producto::findOrFail($request->id);

$validator = Validator::make($request->all(),[

    'nombre' => 'required',
    'codigo' => 'required',
    'description' => 'required',
    
  
         
    
            ]);

            // if($request->hasFile('img')){

            //     $destination = 'users/'.$usuario->img;
            //     if(File::exists($destination)){
                
            //     File::delete($destination);
                
            //     }
                
              
                
                
                
            //     }


            if ($validator ->fails()){
        
        
                // dd('Rellena los campos');  // es lo mismo que decir echo
                
                                return back()
                
                                ->withInput()
                                ->with('alertd','Rellene todos los campos')
                            
                                ->withErrors($validator);
                
                
                } else {
        
                                        //    $file = $request->file('img');
                                        //    $extension = $file->getClientOriginalExtension();
                                        //    $filename = time().'.'.$extension;
                                        //    $file -> move('../img/productos/',$filename);
                                        //    $producto->img = $filename;

                                   //asi se llama en el input el name




                                   if($request->hasFile('img')){

                                    $file =  $request->file('img');
                                    $extension = $file->getClientOriginalExtension();
                                    $filename = time(). '.' . $extension;
                                    $file-> move('./img/productos/',$filename);
                                    $producto->img = $filename;
                                    

                                    }

                                    $producto->author = $request->author;  
                                    $producto->admin = $request->admin;  
                               
                                   $producto->nombre = $request->nombre;   
                                   $producto->codigo = $request->codigo; 
                                   $producto->description = $request->description;
                                   $producto->slug = Str::slug($request->nombre); 
                                 
                                 

//para la contraseña

$validator2 = Validator::make($request->all(),[


    'description' => 'required', 
              //requerido / minimo 3 charact //requerido con el password2 / y que sea igual al password2
                 
    
            ]);

            //si No Falla se va actualizar el password(osea sino se pone bien se actualiza lo de arriba y esto lo ignora)
            if(!$validator2->fails()){


            }

            
            //para la contraseña


            $producto->save();   
            return redirect('community');


} //llave else validar




} //llave else validar

                      



                    

  
    





  
    










    

    public function destroy($id)
    {
        $producto = Producto::find($id);
        $producto->delete();
        return back()->with('Listo','El Registro se ha Eliminado Correctamente');







        
    }
    



























    public function indexcom()
    {
     
     //usando modelo
        $productos = Producto::all();
        
       

        $search = request()->query('search') ;

        if($search){
        
           
            $posts = Producto::where('nombre', 'LIKE', "%{$search}%")->simplePaginate(3);
        
        
        } else{
        
        $posts = Producto::OrderBy('id','ASC')->where('admin','=','no')->take(200)->get();
        
        }



        return view('community') -> with('productos',$posts);
        
          
        

        
    }








   
public function showedit(Producto $id, Request $request)
{

  

    $usuarios = User::all();

   
            
 
  

    $productos = Producto::find($id);

 

    return view('postcom',compact('productos'))->with('usuarios', auth()->user());;


// dd($productos);
  
 
// dd($comentariologins);

}


 
public function red2()
{
 
 
   
    
    return redirect('programming');
    


}


public function delete3(Request $request)
{
   
    $usuario_id = Auth::user()->id;

    $usuario = User::findOrFail($usuario_id);


    $producto = Producto::findOrFail($request->id);



    
    
    
               $producto->delete();   
              
             
               
       
    
               
               
               
              
               
               
               return view('postdeleteconfirm');
               
              



}











public function updatepost(Request $request)
{
    
$producto = Producto::findOrFail($request->id);

$validator = Validator::make($request->all(),[

'nombre' => 'required',
'codigo' => 'required',
'description' => 'required',


     

        ]);

        // if($request->hasFile('img')){

        //     $destination = 'users/'.$usuario->img;
        //     if(File::exists($destination)){
            
        //     File::delete($destination);
            
        //     }
            
          
            
            
            
        //     }


        if ($validator ->fails()){
    
    
            // dd('Rellena los campos');  // es lo mismo que decir echo
            
                            return back()
            
                            ->withInput()
                            ->with('Alertd','Rellene todos los campos')
                        
                            ->withErrors($validator);
            
            
            } else {
    
                                    //    $file = $request->file('img');
                                    //    $extension = $file->getClientOriginalExtension();
                                    //    $filename = time().'.'.$extension;
                                    //    $file -> move('../img/productos/',$filename);
                                    //    $producto->img = $filename;

                               //asi se llama en el input el name




                               if($request->hasFile('img')){

                                $file =  $request->file('img');
                                $extension = $file->getClientOriginalExtension();
                                $filename = time(). '.' . $extension;
                                $file-> move('./img/productos/',$filename);
                                $producto->img = $filename;
                                

                                }

                                $producto->author = $request->author;  
                                $producto->admin = $request->admin;  
                               $producto->stock = $request->stock;  
                               $producto->nombre = $request->nombre;   
                               $producto->codigo = $request->codigo; 
                               $producto->description = $request->description;
                               $producto->slug = Str::slug($request->nombre); 
                             
                             

//para la contraseña

$validator2 = Validator::make($request->all(),[


'description' => 'required', 
          //requerido / minimo 3 charact //requerido con el password2 / y que sea igual al password2
             

        ]);

        //si No Falla se va actualizar el password(osea sino se pone bien se actualiza lo de arriba y esto lo ignora)
        if(!$validator2->fails()){


        }

        
        //para la contraseña


        $producto->save();   
        return back()->with('Listo','El Registro se ha Editado');


} //llave else validar

                  }





    
public function redcom()
{
 
 
   
    
    return redirect('community');
    


}



}
