<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Auth;


use App\Models\Producto;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManagerStatic;
use Barryvdh\DomPDF\Facade as PDF;
use App\Models\Comentario;
use App\Models\Comentariologin;

class ProgrammingController extends Controller
{
    
    public function index()
    {
     
     //usando modelo
        $productos = Producto::all();
        $comentarios = Comentario::Paginate(3);

        $search = request()->query('search') ;

        if($search){
        
           
            $posts = Producto::where('description', 'LIKE', "%{$search}%")->simplePaginate(3);
        
        
        } else{
        
        $posts = Producto::Paginate();
        
        }
        


        
        
        
       
        
        
        return view('programming',compact('comentarios')) -> with('productos',$posts);
        
          
        
        

        // $productos = DB::table('productos') // la tabla que voy a usar
        // ->select('productos.*') // .* significa para todos los campos
        //               //ascendente
        // ->OrderBy('stock','ASC')
       

        // ->get();


    }







public function show(Request $request,Producto $id, Comentariologin $post_id)
{
   
    
    
    

    
    
  

    $productos = Producto::find($id);

   


    $usuarios = User::all();

    $comentariologins =  Comentariologin::find($id,'user_id');
            
    dd($comentariologins);
 
}








// public function getComment(Producto $id, Comentariologin $post_id)
// {
    
    
   
    
//     $productos = Producto::find($id);

//     $comentariologins = Comentariologin::all();

//     $usuarios = User::all();

            
//     return view('post',compact('comentariologins','productos','usuarios'));
 
// }




// -------------------------------------------------


// public function detail(Producto $id, Comentariologin $post_id)
// {
   
    
//     $productos = Producto::with('comentariologins')->find($id);

//            $comentariologins = Comentariologin::all();

//      $usuarios = User::find($id);
   
            
//  return view('post')->with('comentariologins',$productos->id);
 
// }


// -------------------------------------



// Backup

// public function show(Producto $id)
// {
   
    
//     $productos = Producto::find($id);

//     $comentariologins =  Comentariologin::where('post_id',$id)->get;

//     $usuarios = User::find($id);


            
//  return view('post',compact('comentariologins','productos','usuarios'));
 
// }


// public function show(Producto $producto)
// {
//     return view('posts.show',compact('productos'));
// }



}
