<?php

namespace App\Http\Controllers;

use App\Models\Comentario;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Auth;

use App\Models\Comentariologin;
use App\Models\Producto;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManagerStatic;
use Barryvdh\DomPDF\Facade as PDF;


class ComentariologinsController extends Controller
{
    

    public function __construct()
    {       
           //el middlewaree son los que estan entree la peticion y el controlleer
        $this->middleware(['auth','verified']);
    }
    
    


    public function index()
    {

        $comentariologins = Comentariologin::all();
     
        $search = request()->query('search') ;

        if($search){
        
        
            $posts = Comentariologin::where('comment', 'LIKE', "%{$search}%")->Paginate(2);
        
        
        } else{
        
        $posts = Comentariologin::Paginate();
        
        }


     //usando modelo
  

        
     return view('commentlogins') -> with('comentariologins',$posts);
        

        
          
        
        

        // $productos = DB::table('productos') // la tabla que voy a usar
        // ->select('productos.*') // .* significa para todos los campos
        //               //ascendente
        // ->OrderBy('stock','ASC')
       

        // ->get();


    }

public function showlogin(Comentariologin $id)
{
    $productos = Comentariologin::find($id);
    
    return view('commentlogins', compact('comentariologins'));
 
}




public function update(Request $request)
{



    $comentariologin = Comentariologin::findOrFail($request->ids);
    

    $validator = Validator::make($request->all(),[

      
        'comment' => 'required',
        
      
             
        
                ]);


                

            if ($validator ->fails()){
        
        
                // dd('Rellena los campos');  // es lo mismo que decir echo
                
                                return back()
                
                                ->withInput()
                                ->with('Listo','fill in all the fields')
                            
                                ->withErrors($validator);
                
                
                } else {  
    

    $comentariologin->ids = $request->ids;


                    $comentariologin->ids = $request->ids;

$comentariologin->user_id = $request->user_id;

$comentariologin->edit = $request->edit;



$comentariologin->comment = $request->comment;




           $comentariologin->update();   
          
           return back()->with('Listo','Your comment has been edited');



        }




}



public function store(Producto $id, Request $request)
{
    $productos = Producto::find($id);

    $usuarios = User::find($request->id);

    

    $comentariologins = Comentariologin::all();



    $validator = Validator::make($request->all(),[

        
                   
        'comment' => 'required', 
                      
        
                ]);
        
        if ($validator ->fails()){
        
        
        // dd('Rellena los campos');  // es lo mismo que decir echo
        
                        return back()
        
                        ->withInput()
                        ->with('Listo','fill in all the fields')
                    
                        ->withErrors($validator);
        
        
        } else {
        
            

        
        $comentariologin = Comentariologin::create([
        
        'user_id'=>$request->user_id,

        'edit'=>'',
       
        'id'=>$request->id,

        'comment'=>$request->comment,

        
       
        
        ]);
        
         return back()->with('Listo','Your comment has been uploaded');
        
        }
        
        
        
                // dd($request); esto interrumpe la coneccion eentonces lo saco
        
         // si solo quiero el atributo nombre / dd($request->$nombre);
            }


          







  

            public function delete(Request $request)
            {
               
              
                $comentariologin = Comentariologin::findOrFail($request->id);
    

            
                
                
                
                           $comentariologin->delete();   
                          
                           return back()->with('Listo','Your comment has been deleted');
                
                
        
        
        
        
        
                
            }

            public function delete2(Request $request)
            {
               
                $usuario_id = Auth::user()->id;

                $usuario = User::findOrFail($usuario_id);


                $comentariologin = Comentariologin::findOrFail($request->id);
    

            
                
                
                
                           $comentariologin->delete();   
                          
                           $productos = Producto::all();
                           $comentarios = Comentario::Paginate(3);
                   
                           $search = request()->query('search') ;
                   
                           if($search){
                           
                              
                               $posts = Producto::where('description', 'LIKE', "%{$search}%")->simplePaginate(3);
                           
                           
                           } else{
                           
                           $posts = Producto::all();
                           
                           }
                           
                   
                   
                           
                           
                           
                          
                           
                           
                           return view('commentdeleteconfirm');
                           
                          
        
        
        
        
        
                
            }











        }






