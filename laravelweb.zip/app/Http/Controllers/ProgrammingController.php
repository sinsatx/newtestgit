<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Auth;


use App\Models\Producto;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManagerStatic;
use Barryvdh\DomPDF\Facade as PDF;
use App\Models\Comentario;
use App\Models\Comentariologin;

class ProgrammingController extends Controller
{
    
    
 

    public function index()
    {
     
     //usando modelo
        $productos = Producto::all();
        
        $comentarios = Comentario::Paginate(3);

        $search = request()->query('search') ;

        if($search){
        
           
            $posts = Producto::where('nombre', 'LIKE', "%{$search}%")->simplePaginate(3);
        
        
        } else{
        
        $posts = Producto::OrderBy('id','ASC')->where('admin','=','yes')->take(200)->get();
        
        }
        


        
        
        
       
        
        
        return view('programming',compact('comentarios')) -> with('productos',$posts);
        
          
        
        

        // $productos = DB::table('productos') // la tabla que voy a usar
        // ->select('productos.*') // .* significa para todos los campos
        //               //ascendente
        // ->OrderBy('stock','ASC')
       

        // ->get();


    }







public function show(Producto $id, Request $request)
{

  

    $usuarios = User::all();

    $comentariologins =  Comentariologin::OrderBy('ids','ASC')->where('id','=',$id->id)->take(20)->get();
            
    $latestPosts = Producto::inRandomOrder()->where('id','!=',$id->id)->take(3)->get();
    
  

    $productos = Producto::find($id);

 

     return view('post',compact('comentariologins','productos','usuarios'),['latestPosts'=>$latestPosts])->with('usuarios', auth()->user());;

// dd($productos);
  
 
// dd($comentariologins);

}


public function edit(Comentariologin $id)
{
   
    
    
    

    $usuarios = User::all();

    $comentariologins =  Comentariologin::find($id);
            
    $latestPosts = Producto::inRandomOrder()->where('id','!=',$id->id)->take(3)->get();
    
  

    $productos = Producto::find($id);

 

     return view('postcomment',compact('comentariologins','productos','usuarios'),['latestPosts'=>$latestPosts]);

// dd($productos);
  
 
// dd($comentariologins);

}


public function delete(Request $request)
{
   
    $comentariologin = Comentariologin::findOrFail($request->id);



    
    
    
               $comentariologin->delete();   
              
               return back()->with('Listo','Your comment has been deleted');
    
    





    
}



public function search(Request $request)
{
   

    $term = $request->get('term');


     $querys = Producto::where('nombre', 'LIKE', '%' . $term . '%')->select('nombre as label')  ->get(); 


     

     return $querys;
    
 




    
}



public function searchus(Request $request)
{
   

    $term = $request->get('term');

    $querys = User::where('email', 'LIKE', '%' . $term . '%')->select('email as label')  ->get(); 

     return $querys;
    
 




    
}



public function searchcommentwithoutlog(Request $request)
{
   

    $term = $request->get('term');

    $querys = Comentario::where('user', 'LIKE', '%' . $term . '%')->select('user as label')  ->get(); 

     return $querys;
    
 




    
}

public function searchcommentlog(Request $request)
{
   

    $term = $request->get('term');

    $querys = Comentariologin::where('comment', 'LIKE', '%' . $term . '%')->select('comment as label')  ->get(); 

     return $querys;
    
 




    
}

public function searchproduct(Request $request)
{
   

    $term = $request->get('term');

  $querys = Producto::where('nombre', 'LIKE', '%' . $term . '%')->select('nombre as label')  ->get(); 


     return $querys;
    
 




    
}



// public function getComment(Producto $id, Comentariologin $post_id)
// {
    
    
   
    
//     $productos = Producto::find($id);

//     $comentariologins = Comentariologin::all();

//     $usuarios = User::all();

            
//     return view('post',compact('comentariologins','productos','usuarios'));
 
// }




// -------------------------------------------------


// public function detail(Producto $id, Comentariologin $post_id)
// {
   
    
//     $productos = Producto::with('comentariologins')->find($id);

//            $comentariologins = Comentariologin::all();

//      $usuarios = User::find($id);
   
            
//  return view('post')->with('comentariologins',$productos->id);
 
// }


// -------------------------------------



// Backup

// public function show(Producto $id)
// {
   
    
//     $productos = Producto::find($id);

//     $comentariologins =  Comentariologin::where('post_id',$id)->get;

//     $usuarios = User::find($id);


            
//  return view('post',compact('comentariologins','productos','usuarios'));
 
// }


// public function show(Producto $producto)
// {
//     return view('posts.show',compact('productos'));
// }


 
public function red()
{
 
 
   
    
    return redirect('programming');
    


}




}
