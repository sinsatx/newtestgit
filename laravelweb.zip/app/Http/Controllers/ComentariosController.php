<?php

namespace App\Http\Controllers;

use App\Models\Comentario;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Auth;


use App\Models\Producto;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManagerStatic;
use Barryvdh\DomPDF\Facade as PDF;


class ComentariosController extends Controller
{
    

  


    public function index()
    {

        $comentarios = Comentario::all();
     
        $search = request()->query('search') ;

        if($search){
        
        
            $posts = Comentario::where('user', 'LIKE', "%{$search}%")->Paginate(2);
        
        
        } else{
        
        $posts = Comentario::Paginate(3);
        
        }


     //usando modelo
  

        
     return view('comments') -> with('comentarios',$posts);
        

        
          
        
        

        // $productos = DB::table('productos') // la tabla que voy a usar
        // ->select('productos.*') // .* significa para todos los campos
        //               //ascendente
        // ->OrderBy('stock','ASC')
       

        // ->get();


    }

public function show(Comentario $id)
{
    
    
    return view('comments', compact('comentarios'));
 
}




public function update(Request $request)
{
    $comentario = Comentario::findOrFail($request->id);
    

    $validator = Validator::make($request->all(),[

        'user' => 'required',
        'descripcion' => 'required',
        
      
             
        
                ]);


                

            if ($validator ->fails()){
        
        
                // dd('Rellena los campos');  // es lo mismo que decir echo
                
                                return back()
                
                                ->withInput()
                                ->with('Listo','fill in all the fields')
                            
                                ->withErrors($validator);
                
                
                } else {  
    

$comentario->user = $request->user;

$comentario->descripcion = $request->descripcion;




           $comentario->update();   
          
           return back()->with('Listo','Your comment has been edited');



        }




}


public function store(Request $request)
{



    $validator = Validator::make($request->all(),[

        'user' => 'required',
                   
        'descripcion' => 'required', 
                      
        
                ]);
        
        if ($validator ->fails()){
        
        
        // dd('Rellena los campos');  // es lo mismo que decir echo
        
                        return back()
        
                        ->withInput()
                        ->with('Listo','fill in all the fields')
                    
                        ->withErrors($validator);
        
        
        } else {
        
            

        
        $comentario = Comentario::create([
        
        'user'=>$request->user,
       
        'descripcion'=>$request->descripcion,

        
       
        
        ]);
        
         return back()->with('Listo','Your comment has been uploaded');
        
        }
        
        
        
                // dd($request); esto interrumpe la coneccion eentonces lo saco
        
         // si solo quiero el atributo nombre / dd($request->$nombre);
            }








  

            public function delete(Request $request)
            {
               
                $comentario = Comentario::findOrFail($request->id);
    

            
                
                
                
                           $comentario->delete();   
                          
                           return back()->with('Listo','Your comment has been deleted');
                
                
        
        
        
        
        
                
            }











        }






