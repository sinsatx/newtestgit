<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Producto;
use App\Models\User;



class Comentariologin extends Model
{



    use HasFactory;


                     //para señalar que es la primarykey
  protected $primaryKey = 'ids';



    protected $table= "comentarioslogin"; 
    
    protected $fillable = ['comment','id','user_id','post_id','edit'];

    //esto de abajo se lo agrege



public function usuario()
{      
                                        // la llave foranea
    return $this->belongsTo(User::class,'user_id');

}




public function producto()
{      
                                        // la llave foranea
    return $this->belongsTo(Producto::class,'id');

}



  
}
