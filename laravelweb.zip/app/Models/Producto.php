<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Comentariologin;

class Producto extends Model
{
 // protected $primaryKey = "id";  // como no use id_producto en la tabla es solo id y no es necesario ya esta en la tabla
 protected $table= "productos"; // para decir que la tabla se llama no es necsario ponerla si solo en la tabla se le agrega una s
    protected $fillable = ['nombre','img','stock','codigo','description','slug','admin','author','userpost_id'];

use HasFactory;
  //esto de abajo se lo agrege


     public function comentariologin()
     {
         return $this->hasMany(Comentariologin::class);
    
     }
    
    public function usuario()
    {
        return $this->hasMany(User::class,'userpost_id');
    
    }
   
    public function getRouteKeyName()
    {
        // return $this->getKeyName();
        return 'slug';
    }


}
