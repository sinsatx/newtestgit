<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('layouts.welcome'); //seria dentro de la carpeta de layouts
    return view('welcome');
});

Route::get('/profile',function(){
return view('profile');


});

Route::get('/about',function(){
    return view("about");
    
    
    });


    
    

        Route::get('/contact',function(){
            return view("contact");
            
            
            });


          





Route::get('/profile/editar',function(){
    return "Estas editando";
    
    
    });
              



// http://localhost:8000/ver/10/email@sade y sale: estas viendo el perfil numero 10con el email email@sade

// como hay 2 parametros si pones el http://localhost:8000/ver/10/ te sale error 

Route::get('/ver/{id}','ProfileController@index');


    // para no tener que poner cada vez profile como esta ahi directamente lo metes en un grupo

                  // prefijo   // admin /alias /alias

    Route:: group(['prefix' => 'admin','as' =>'admin'], function(){

Route::get('/', 'AdminController@index')->name('admin.index');

Route::get('/usuarios', 'UsersController@index');

Route::post('/usuarios/edit', 'UsersController@EditarUsuario');

Route::post('/productos/edit', 'ProductosController@edit');

Route::get('/productos', 'ProductosController@index');

Route::post('/productos/all', 'ProductosController@all');
 
route::get('/productos/imprimir','ProductosController@imprimir');




// Route::post('/usuarios', 'UsersController@store');  voy a usar Resources

// Con Resource usas todo, el ver, editar, crear y eliminar

Route::resource('usuarios','UsersController');



//         /admin/usuario no es necesario

Route::resource('productos','ProductosController');
Route::put('/productos/{id}', 'ProductosController@update'); // actualizar un registro
// Route::destroy('/productos/{id}', 'ProductosController@destroy'); // delete un registro

    });
    

    
    
    
    
    
Auth::routes(['verify' => true]);



Route::get('/search/productos','ProgrammingController@search')->name('search.products');
  

Route::get('/search/usuarios','ProgrammingController@searchus')->name('search.users');
  

Route::get('/search/commentwithoutlog','ProgrammingController@searchcommentwithoutlog')->name('search.commentwithoutlog');
  
Route::get('/search/commentlog','ProgrammingController@searchcommentlog')->name('search.commentlog');
  

Route::get('/search/products','ProgrammingController@searchproduct')->name('search.product');
  







 Route::get('/home', "HomeController@index")->name('home')->middleware('verified');

    


   
 Route::get('/admin/productos','ProductosController@index');


             
    Route::get('programming','ProgrammingController@index');

  

    Route::get('settingprofile','SettingController@edit')->name('setting');;

    
//este post lo agrege

     Route::put('settingprofile','SettingController@update')->name('users.update-profile');


     Route::get('setting','SettingController@index');


     Route::resource('settingdelete','SettingController');


     Route::get('settingdelete','SettingController@delet');


     
     Route::get('settingpassword','SettingController@password');

     Route::put('settingpassword','SettingController@password2')->name('users.editpassword');


     
     Route::get('/settingdeleteconfirm',function(){
        return view("settingdeleteconfirm");
        
        
        });

    
     Route::get('/cookies',function(){
        return view("cookies");
        
        
        });


 
        Route::get('/videos',function(){
            return view("videos");
            
            
            });

        
     Route::get('/login2',function(){
        return view("auth.login2");
        
        
        });



        Route::get('/contact', 'EmailController@create');
Route::post('/contact', 'EmailController@sendEmail')->name('send.email');



Route::get('/programming/{id}','ProgrammingController@post')->name('post');




Route::get('/relaciones', 'RelacionesController@showrel');





                                                         //asi esta el nombre en el route de programming blade

Route::get('/post/{id}','ProgrammingController@show')->name('posts.show');


Route::get('/comment/number-{id}','ProgrammingController@edit')->name('comment.show');

Route::delete('/commentdeleteconfirm','ComentariologinsController@delete2')->name('logincoment-delete2');

Route::get('/commentdeleteconfirm','ProgrammingController@red');


// ----------------------------------------------------------------


// ---------------------------------------------------------

// Route::get('/post/{id}','ProgrammingController@show')->name('posts.show');





// Route::get('post/{post}','ProgrammingController@show')->name('posts.path');



// Route::get('/post/{postId}','ProgrammingController@post')->name('post');

//  Route::get('/post/{producto}',[ProgrammingController::class,'programming'])->name('posts.show');


// Route::put('admin/productos/{id}', 'ProductosController@update'); // actualizar un registro

// Route::destroy('admin/productos/{id}', 'ProductosController@destroy'); // delete un registro


Route::get('/admin/comments',function(){
    return view("comments");
    
    
    });

Route::resource('/admin/comments','ComentariosController');


Route::get('/admin/comments','ComentariosController@index');


Route::post('/admin/comments','ComentariosController@store')->name('coment-create');



Route::delete('/admin/comments','ComentariosController@delete')->name('coment-delete');


Route::put('/admin/comments','ComentariosController@update')->name('coment-update');



// --------------------------------------------------------------

Route::get('/admin/commentlogins',function(){
    return view("commentlogins");
    
    
    });

Route::resource('/admin/commentlogins','ComentariologinsController');


Route::get('/admin/commentlogins','ComentariologinsController@index');


Route::post('/admin/commentlogins','ComentariologinsController@store')->name('logincoment-create');



Route::delete('/admin/commentlogins','ComentariologinsController@delete')->name('logincoment-delete');


Route::put('/admin/commentlogins','ComentariologinsController@update')->name('logincoment-update');


// ------------------------------------------------

// Route::resource('productos','ProductosController');
    
//     Route::post('/productos/edit', 'ProductosController@edit');

// Route::get('/productos', 'ProductosController@index');

// Route::post('/productos/all', 'ProductosController@all');
    




  // --------------------------------------------- Community

  Route::get('community','CommunityController@indexcom');


   Route::get('community/posts','CommunityController@index');

   Route::post('/create','CommunityController@store')->name('creatpost');
   


   Route::get('/post/{id}/adm','CommunityController@showedit')->name('postcom.show');


   Route::put('/post/adm/update','CommunityController@update')->name('postadm.edit');
   
   
   Route::delete('/postdeleteconfirm','CommunityController@delete3')->name('post-delete3');
   
   

   Route::get('/postdeleteconfirm','CommunityController@redcom');

  
//   Route::resource('community/posts','CommunityController');


//   Route::post('/community/posts','ProgrammingController@createcom')->name('com-create');

//   Route::put('/community/posts','ProgrammingController@editcom')->name('com-edit');

//   Route::delete('/community/posts','ProgrammingController@editcom')->name('com-delete');



// -------------------------------------------------



